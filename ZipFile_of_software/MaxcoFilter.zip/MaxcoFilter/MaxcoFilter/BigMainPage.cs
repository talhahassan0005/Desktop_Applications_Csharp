﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class BigMainPage : Form
    {
        public BigMainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SupplierMainForm supplierMainForm = new SupplierMainForm();
           
            supplierMainForm.Show();
        }
     

        private void button2_Click(object sender, EventArgs e)
        {
            CustomerMainPage cutomerMainForm = new CustomerMainPage();

            cutomerMainForm.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
