﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class SupplierProduct : Form
    {
        private string connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"; // Replace with your actual database connection string

        private DataTable productsDataTable;
        private DataTable categoriesDataTable;
        public SupplierProduct()
        {
            InitializeComponent();
            LoadCategories();
            LoadProducts();
            LoadSupplierNames();
            DataGridviewProduct.CellClick += new DataGridViewCellEventHandler(DataGridviewProduct_CellClick);

            // Ensure that the event handler for the delete button is attached only once
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click_1);
        }



        private void DataGridviewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Get the ProductId from the DataGridView
                if (int.TryParse(Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["ProductId"].Value), out int productId))
                {
                    // Fetch TotalAmount, PaidAmount, and UnPaidAmount from the database based on productId
                    PopulateAdditionalFields(productId);

                    // Enable the update button or perform any other actions needed after selecting a product
                    btnUpdate.Enabled = true;

                    // Populate other fields if needed
                    textSupProd.Text = Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["ProductName"].Value);
                    textSupProdDes.Text = Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["ProductDescription"].Value);
                    textSupProdQty.Text = Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["ProductQty"].Value);
                    textSupProdPrice.Text = Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["ProductPrice"].Value);
                    textSupProdUnit.Text = Convert.ToString(DataGridviewProduct.Rows[e.RowIndex].Cells["Unit"].Value);
                }
                else
                {
                    MessageBox.Show("Invalid Product ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void PopulateAdditionalFields(int productId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT TotalAmount, PaidAmount, UnpaidAmount FROM SupplierProduct WHERE ProductId = @ProductId";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@ProductId", productId);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Populate the additional fields from the database after checking for DBNull
                        textTotalAmount.Text = reader.IsDBNull(0) ? string.Empty : reader.GetDecimal(0).ToString();
                        textPaid.Text = reader.IsDBNull(1) ? string.Empty : reader.GetDecimal(1).ToString();
                        textUnpaidAmount.Text = reader.IsDBNull(2) ? string.Empty : reader.GetDecimal(2).ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while fetching additional data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void LoadSupplierNames()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Supplierid, SupplierName FROM Suppliers";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable supplierDataTable = new DataTable();
                adapter.Fill(supplierDataTable);
                comSupplier.DataSource = supplierDataTable;
                comSupplier.DisplayMember = "SupplierName";
                // If you want to associate a value with each supplier (e.g., SupplierID), you can use:
                comSupplier.ValueMember = "SupplierID";
            }
        }
        private void UpdateTotalAmount()
        {


            if (int.TryParse(textSupProdQty.Text, out int productQty) && float.TryParse(textSupProdPrice.Text, out float productPrice))
            {
                float totalAmount = productQty * productPrice;
                textTotalAmount.Text = totalAmount.ToString();
            }
            else
            {
                // Handle the case where the input is not valid (e.g., non-numeric values).
                textTotalAmount.Text = string.Empty;
            }
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            UpdateTotalAmount();
        }
        private void LoadCategories()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Catid, CatName FROM SupplierCategory";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                categoriesDataTable = new DataTable();
                adapter.Fill(categoriesDataTable);
                comboSupCate.DataSource = categoriesDataTable;
                comboSupCate.DisplayMember = "CatName";
                comboSupCate.ValueMember = "CatId";
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT P.ProductId, P.ProductName, P.ProductDescription, P.ProductQty, P.ProductPrice, P.Unit, C.CatName AS ProductCategory " +
                                    "FROM SupplierProduct P " +
                                    "INNER JOIN SupplierCategory C ON P.ProductCategory = C.CatId";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    productsDataTable = new DataTable();
                    adapter.Fill(productsDataTable);
                    DataGridviewProduct.DataSource = productsDataTable; // Correct the control name here
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ClearFormFields()
        {
            textSupProd.Clear();
            textSupProdDes.Clear();
            textSupProdQty.Clear();
            textSupProdPrice.Clear();
            textSupProdUnit.Clear();
            textPaid.Clear();
            textTotalAmount.Clear();
            textUnpaidAmount.Clear();
        }
        private int GetProductId(string productName)
        {
            int productId = -1; // Default value if not found

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT Productid FROM SupplierProduct WHERE ProductName = @ProductName";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ProductName", productName);
                    var result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        productId = (int)result; // Parse the result to an integer
                    }
                }
            }

            return productId;
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            try
            {
                string productName = textSupProd.Text;
                string productDescription = textSupProdDes.Text;
                int productQty = int.Parse(textSupProdQty.Text);
                float productPrice = float.Parse(textSupProdPrice.Text);
                string productUnit = textSupProdUnit.Text;
                int categoryId = (int)comboSupCate.SelectedValue;
                int supplierid = (int)comSupplier.SelectedValue;
                float totalAmount = float.Parse(textTotalAmount.Text);
                float paidAmount = float.Parse(textPaid.Text);
                float unpaidAmount = float.Parse(textUnpaidAmount.Text);
                DateTime date = dateTimePicker1.Value;






                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string insertQuery = "INSERT INTO SupplierProduct (ProductName, ProductDescription, ProductQty, ProductPrice, Unit, ProductCategory, TotalAmount, PaidAmount, UnpaidAmount, SupplierId, Date) " +
                               "VALUES (@ProductName, @ProductDescription, @ProductQty, @ProductPrice, @Unit, @ProductCategory, @TotalAmount, @PaidAmount, @UnpaidAmount, @SupplierId, @Date)";
                        using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ProductName", productName);
                            cmd.Parameters.AddWithValue("@ProductDescription", productDescription);
                            cmd.Parameters.AddWithValue("@ProductQty", productQty);
                            cmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                            cmd.Parameters.AddWithValue("@Unit", productUnit);
                            cmd.Parameters.AddWithValue("@ProductCategory", categoryId);
                            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                            cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                            cmd.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);
                            cmd.Parameters.AddWithValue("@SupplierId", supplierid);
                            cmd.Parameters.AddWithValue("@Date", date);
                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Product added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadProducts();
                                ClearFormFields();
                            }
                            else
                            {
                                MessageBox.Show("Product could not be added.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }



                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string insertQuery = "INSERT INTO ProductStockIn (ProductName, ProductDescription, ProductQty, ProductPrice, Unit, ProductCategory, TotalAmount, PaidAmount, UnpaidAmount, SupplierId, Date) " +
                               "VALUES (@ProductName, @ProductDescription, @ProductQty, @ProductPrice, @Unit, @ProductCategory, @TotalAmount, @PaidAmount, @UnpaidAmount, @SupplierId, @Date)";
                        using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ProductName", productName);
                            cmd.Parameters.AddWithValue("@ProductDescription", productDescription);
                            cmd.Parameters.AddWithValue("@ProductQty", productQty);
                            cmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                            cmd.Parameters.AddWithValue("@Unit", productUnit);
                            cmd.Parameters.AddWithValue("@ProductCategory", categoryId);
                            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                            cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                            cmd.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);
                            cmd.Parameters.AddWithValue("@SupplierId", supplierid);
                            cmd.Parameters.AddWithValue("@Date", date);
                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                // MessageBox.Show("Product added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadProducts();
                                ClearFormFields();
                            }
                            else
                            {
                                MessageBox.Show("Product could not be added.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }



                int productId = GetProductId(productName);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string insertQuery = "INSERT INTO SupplierStockIn (ProductQty, PaidAmount, PayableAmount, Supplierid, Productid,TotalAmount) " +
                                            "VALUES (@ProductQty, @PaidAmount, @PayableAmount, @Supplierid, @Productid,@TotalAmount)";


                        using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                        {
                            //int productId = GetProductId(productName); // Retrieve the productId using your GetProductId function

                            // Check if the productId is valid (not -1)
                            if (productId != -1)
                            {
                                // Add the @ProductId parameter to the query
                                cmd.Parameters.AddWithValue("@ProductId", productId);
                                cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                                cmd.Parameters.AddWithValue("@PayableAmount", unpaidAmount);
                                cmd.Parameters.AddWithValue("@ProductQty", productQty);
                                cmd.Parameters.AddWithValue("@Supplierid", supplierid);
                                cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);

                                // ... add other parameters and execute the query
                                int rowsAffected = cmd.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Product added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LoadProducts();
                                    ClearFormFields();
                                }
                                else
                                {
                                    MessageBox.Show("Product could not be added.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Product not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }


                }


            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }










        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (DataGridviewProduct.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int selectedRowIndex = DataGridviewProduct.SelectedRows[0].Index;
            int productId = Convert.ToInt32(DataGridviewProduct.Rows[selectedRowIndex].Cells["ProductId"].Value);

            // Get the updated values from the form fields
            string productName = textSupProd.Text;
            string productDescription = textSupProdDes.Text;
            int.TryParse(textSupProdQty.Text, out int productQty);
            decimal productPrice = decimal.Parse(textSupProdPrice.Text);
            string productUnit = textSupProdUnit.Text;
            int categoryId = (int)comboSupCate.SelectedValue;
            decimal totalAmount = decimal.Parse(textTotalAmount.Text);
            decimal paidAmount = decimal.Parse(textPaid.Text);
            decimal unpaidAmount = decimal.Parse(textUnpaidAmount.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string selectQuery = "SELECT ProductQty, TotalAmount, PaidAmount, UnpaidAmount FROM SupplierProduct WHERE ProductId = @ProductId";

                    using (SqlCommand selectCmd = new SqlCommand(selectQuery, connection))
                    {
                        selectCmd.Parameters.AddWithValue("@ProductId", productId);

                        SqlDataReader reader = selectCmd.ExecuteReader();

                        int existingQty = 0;
                        decimal existingTotalAmount = 0;
                        decimal existingPaidAmount = 0;
                        decimal existingUnpaidAmount = 0;

                        if (reader.Read())
                        {
                            // Instead of directly using GetInt32 and GetDecimal, it's safer to use TryGetX methods to handle potential null values or incorrect data types
                            int.TryParse(reader["ProductQty"].ToString(), out existingQty);
                            decimal.TryParse(reader["TotalAmount"].ToString(), out existingTotalAmount);
                            decimal.TryParse(reader["PaidAmount"].ToString(), out existingPaidAmount);
                            decimal.TryParse(reader["UnpaidAmount"].ToString(), out existingUnpaidAmount);
                        }
                        reader.Close();

                        // Calculate new values
                        int updatedQty = existingQty + productQty;
                        decimal updatedTotalAmount = existingTotalAmount + (productPrice * productQty);
                        decimal updatedPaidAmount = existingPaidAmount + paidAmount;
                        decimal updatedUnpaidAmount = updatedTotalAmount - updatedPaidAmount;

                        // If the unpaid amount goes negative, adjust the paid and unpaid amounts
                        if (updatedUnpaidAmount < 0)
                        {
                            // Add the excess to the paid amount
                            updatedPaidAmount += Math.Abs(updatedUnpaidAmount);

                            // Set unpaid amount to zero
                            updatedUnpaidAmount = 0;

                            // Add the negative value to the previous UnPaidAmount
                            updatedUnpaidAmount += existingUnpaidAmount;
                        }


                        string updateQuery = "UPDATE SupplierProduct " +
                                             "SET ProductName = @ProductName, ProductDescription = @ProductDescription, ProductQty = @ProductQty, " +
                                             "ProductPrice = @ProductPrice, Unit = @Unit, ProductCategory = @ProductCategory, " +
                                             "TotalAmount = @TotalAmount, PaidAmount = @PaidAmount, UnpaidAmount = @UnpaidAmount " +
                                             "WHERE ProductId = @ProductId";

                        using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ProductId", productId);
                            cmd.Parameters.AddWithValue("@ProductName", productName);
                            cmd.Parameters.AddWithValue("@ProductDescription", productDescription);
                            cmd.Parameters.AddWithValue("@ProductQty", updatedQty);
                            cmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                            cmd.Parameters.AddWithValue("@Unit", productUnit);
                            cmd.Parameters.AddWithValue("@ProductCategory", categoryId);
                            cmd.Parameters.AddWithValue("@TotalAmount", updatedTotalAmount);
                            cmd.Parameters.AddWithValue("@PaidAmount", updatedPaidAmount);
                            cmd.Parameters.AddWithValue("@UnpaidAmount", updatedUnpaidAmount);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Product updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadProducts(); // Refresh the DataGridView after the update
                                ClearFormFields(); // Clear the form fields after the update
                            }
                            else
                            {
                                MessageBox.Show("Product could not be updated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if a product is selected in the DataGridView
            if (DataGridviewProduct.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int selectedRowIndex = DataGridviewProduct.SelectedRows[0].Index;
            int productId = Convert.ToInt32(DataGridviewProduct.Rows[selectedRowIndex].Cells["ProductId"].Value);

            // Confirm deletion with a warning message box
            if (MessageBox.Show("Are you sure you want to delete this product?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string deleteQuery = "DELETE FROM SupplierProduct WHERE ProductId = @ProductId";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@ProductId", productId);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Product deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadProducts();
                                ClearFormFields();
                            }
                            else
                            {
                                MessageBox.Show("Product could not be deleted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void comboSupCate_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textSupProdQty_TextChanged(object sender, EventArgs e)
        {
            UpdateTotalAmount();
        }

        private void SupplierProduct_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textTotalAmount_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateUnpaidAmount()
        {
            if (decimal.TryParse(textTotalAmount.Text, out decimal totalAmount) && decimal.TryParse(textPaid.Text, out decimal paidAmount))
            {
                decimal unpaidAmount = totalAmount - paidAmount;
                textUnpaidAmount.Text = unpaidAmount.ToString();
            }
            else
            {
                // Handle the case where the input is not valid (e.g., non-numeric values).
                textUnpaidAmount.Text = string.Empty;
            }
        }
        private void textPaid_TextChanged(object sender, EventArgs e)
        {
            UpdateUnpaidAmount();
        }

        private void SearchProduct_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = SearchProduct.Text.Trim();

            DataView dv = productsDataTable.DefaultView;
            dv.RowFilter = $"ProductName LIKE '%{searchTerm}%'"; // Filtering based on ProductName
            DataGridviewProduct.DataSource = dv.ToTable();
        }


        private void DeleteRelatedPayments(SqlConnection connection, int productId)
        {
            // Delete related payments from SupplierStockIn table
            string deletePaymentsQuery = "DELETE FROM SupplierStockIn WHERE ProductId = @ProductId";
            using (SqlCommand deletePaymentsCmd = new SqlCommand(deletePaymentsQuery, connection))
            {
                deletePaymentsCmd.Parameters.AddWithValue("@ProductId", productId);
                deletePaymentsCmd.ExecuteNonQuery();
            }
        }
        private void btnDelete_Click_1(object sender, EventArgs e)
        {

            if (DataGridviewProduct.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = DataGridviewProduct.SelectedRows[0];

            // Get the productId from the selected row (assuming your productId column is named "ProductId")
            int productId = Convert.ToInt32(selectedRow.Cells["ProductId"].Value);

            // Show confirmation dialog before deletion
            DialogResult confirmationResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmationResult == DialogResult.Yes)
            {
                // Perform deletion of associated records in SupplierStockIn table
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        // Delete related payments from SupplierStockIn table
                        string deletePaymentsQuery = "DELETE FROM SupplierStockIn WHERE Productid = @ProductId";
                        using (SqlCommand deletePaymentsCmd = new SqlCommand(deletePaymentsQuery, connection))
                        {
                            deletePaymentsCmd.Parameters.AddWithValue("@ProductId", productId);
                            deletePaymentsCmd.ExecuteNonQuery();
                        }

                        // After deleting related records in SupplierStockIn, delete the record from SupplierProduct
                        string deleteProductQuery = "DELETE FROM SupplierProduct WHERE ProductId = @ProductId";
                        using (SqlCommand deleteProductCmd = new SqlCommand(deleteProductQuery, connection))
                        {
                            deleteProductCmd.Parameters.AddWithValue("@ProductId", productId);
                            int rowsAffected = deleteProductCmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadProducts(); // Assuming this method reloads the DataGridView with updated data
                                ClearFormFields(); // Assuming this method clears form fields after deletion
                            }
                            else
                            {
                                MessageBox.Show("Record could not be deleted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void SupplierProduct_Click(object sender, EventArgs e)
        {

        }

        private void DataGridviewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
