﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class CustomerStockIn : Form
    {
        private string connectionString = "data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"; // Replace with your actual database connection string

        private DataTable productsDataTable;
        private DataTable categoriesDataTable;
        public CustomerStockIn()
        {
            InitializeComponent();
            LoadCategories(); // Call this method to populate the ComboBox with categories.
            LoadProducts();
            LoadDataIntoDataGridView();
            custdataGridView.CellClick += custdataGridView_CellClick;
      
            RefreshDataGridView();


        }

        private void RefreshDataGridView()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Customers";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        custdataGridView.DataSource = dataTable;
                    }
                }
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM CompanyStockIn";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        DataGridviewProduct.DataSource = dataTable;
                    }
                }
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM CustomerStockOut";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        dataGridViewStockOut.DataSource = dataTable;
                    }
                }
            }
        }


        private void UpdateTotalAmount()
        {
            if (int.TryParse(textSupProdQty.Text, out int quantity) && decimal.TryParse(textSupProdPrice.Text, out decimal unitPrice))
            {
                // Calculate the total amount
                decimal totalAmount = quantity * unitPrice;

                // Display the calculated total amount
                textTotalAmount.Text = totalAmount.ToString();
            }
            else
            {
                // Handle invalid input
                textTotalAmount.Text = ""; // Clear the TotalAmount field or provide an error message
            }
        }


        private void DataGridviewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = DataGridviewProduct.Rows[e.RowIndex];

                textSupProd.Text = selectedRow.Cells["ProductName"].Value.ToString();
                textSupProdDes.Text = selectedRow.Cells["Description"].Value.ToString();
                textSupProdQty.Text = selectedRow.Cells["Qty"].Value.ToString();
                textSupProdPrice.Text = selectedRow.Cells["Price"].Value.ToString();
                
                comboSupCate.Text = selectedRow.Cells["Category"].Value.ToString();
            }
        }
        private void LoadCategories()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Catid, CatName FROM CustomerCategory";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                categoriesDataTable = new DataTable();
                adapter.Fill(categoriesDataTable);
                comboSupCate.DataSource = categoriesDataTable;
                comboSupCate.DisplayMember = "CatName";
                comboSupCate.ValueMember = "CatId";
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT P.ProductName, P.ProductDescription, P.ProductQty, P.ProductPrice, P.Unit, C.CatName AS ProductCategory " +
                                    "FROM CustomerStockOut P " +
                                    "INNER JOIN CustomerCategory C ON P.ProductCategory = C.CatId";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    productsDataTable = new DataTable();
                    adapter.Fill(productsDataTable);
                    DataGridviewProduct.DataSource = productsDataTable;

                    DataGridviewProduct.CellClick += new DataGridViewCellEventHandler(DataGridviewProduct_CellClick);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFormFields()
        {
            textSupProd.Clear();
            textSupProdDes.Clear();
            textSupProdQty.Clear();
            textSupProdPrice.Clear();
            textSupProdUnit.Clear();
            textPaid.Clear();
            textTotalAmount.Clear();
            textUnpaidAmount.Clear();
            Customer.Clear();
        }
        private int GetProductId()
        {
            int productId = -1; // Default value if not found

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT TOP 1 Productid FROM CustomerStockOut ORDER BY Productid DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    var result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        productId = (int)result; // Parse the result to an integer
                    }
                }
            }

            return productId;

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            try
            {
                string productName = textSupProd.Text;
                string productDescription = textSupProdDes.Text;
                int productQty = int.Parse(textSupProdQty.Text);
                float productPrice = float.Parse(textSupProdPrice.Text);
                string productUnit = textSupProdUnit.Text;
                int categoryId = (int)comboSupCate.SelectedValue;
                int customer = int.Parse(Customer.Text);
                float totalAmount = float.Parse(textTotalAmount.Text);
                float paidAmount = float.Parse(textPaid.Text);
                float unpaidAmount = float.Parse(textUnpaidAmount.Text);
                DateTime date = dateTimePicker1.Value;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string checkQuantityQuery = "SELECT SUM(Qty) FROM CompanyStockIn WHERE ProductName = @ProductName";
                        using (SqlCommand checkQuantityCmd = new SqlCommand(checkQuantityQuery, connection))
                        {
                            checkQuantityCmd.Parameters.AddWithValue("@ProductName", productName);
                            object availableQuantity = checkQuantityCmd.ExecuteScalar();

                            if (availableQuantity == null || Convert.ToInt32(availableQuantity) < productQty)
                            {
                                MessageBox.Show("Quantity is not available.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        string insertQueryCustomerStockOut = "INSERT INTO CustomerStockOut (ProductName, ProductDescription, ProductQty, ProductPrice, Unit, ProductCategory, TotalAmount, PaidAmount, UnpaidAmount, Date, Customerid) " +
                            "VALUES (@ProductName, @ProductDescription, @ProductQty, @ProductPrice, @Unit, @ProductCategory, @TotalAmount, @PaidAmount, @UnpaidAmount, @Date, @Customerid)";

                        using (SqlCommand cmdCustomerStockOut = new SqlCommand(insertQueryCustomerStockOut, connection))
                        {
                            cmdCustomerStockOut.Parameters.AddWithValue("@ProductName", productName);
                            cmdCustomerStockOut.Parameters.AddWithValue("@ProductDescription", productDescription);
                            cmdCustomerStockOut.Parameters.AddWithValue("@ProductQty", productQty);
                            cmdCustomerStockOut.Parameters.AddWithValue("@ProductPrice", productPrice);
                            cmdCustomerStockOut.Parameters.AddWithValue("@Unit", productUnit);
                            cmdCustomerStockOut.Parameters.AddWithValue("@ProductCategory", categoryId);
                            cmdCustomerStockOut.Parameters.AddWithValue("@TotalAmount", totalAmount);
                            cmdCustomerStockOut.Parameters.AddWithValue("@PaidAmount", paidAmount);
                            cmdCustomerStockOut.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);
                            cmdCustomerStockOut.Parameters.AddWithValue("@Customerid", customer);
                            cmdCustomerStockOut.Parameters.AddWithValue("@Date", date);

                            int rowsAffectedCustomerStockOut = cmdCustomerStockOut.ExecuteNonQuery();
                            if (rowsAffectedCustomerStockOut > 0)
                            {
                                MessageBox.Show("Product added to CustomerStockOut successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                ClearFormFields();

                                // Update the quantity in CompanyStockIn
                                string updateQuantityQuery = "UPDATE CompanyStockIn SET Qty = Qty - @ProductQty WHERE ProductName = @ProductName";
                                using (SqlCommand updateQuantityCmd = new SqlCommand(updateQuantityQuery, connection))
                                {
                                    updateQuantityCmd.Parameters.AddWithValue("@ProductName", productName);
                                    updateQuantityCmd.Parameters.AddWithValue("@ProductQty", productQty);
                                    updateQuantityCmd.ExecuteNonQuery();
                                }

                                // Get the CustomerStockOutid from CustomerStockOut table
                                string getCustomerStockOutIdQuery = "SELECT CustomerStockOutid FROM CustomerStockOut WHERE ProductName = @ProductName AND Customerid = @Customerid";
                                int customerStockOutId = 0;
                                using (SqlCommand getCustomerStockOutIdCmd = new SqlCommand(getCustomerStockOutIdQuery, connection))
                                {
                                    getCustomerStockOutIdCmd.Parameters.AddWithValue("@ProductName", productName);
                                    getCustomerStockOutIdCmd.Parameters.AddWithValue("@Customerid", customer);
                                    object result = getCustomerStockOutIdCmd.ExecuteScalar();
                                    if (result != null)
                                    {
                                        customerStockOutId = Convert.ToInt32(result);
                                    }
                                }

                                if (customerStockOutId != 0)
                                {
                                    string insertQueryCustomerBill = "INSERT INTO CustomerBill (UnpaidAmount, PaidAmount, ProductQty, TotalAmount, CustomerStockOutid, Customerid,Date) " +
                                        "VALUES (@UnpaidAmount, @PaidAmount, @ProductQty, @TotalAmount, @CustomerStockOutid, @Customerid,@Date)";

                                    using (SqlCommand cmdCustomerBill = new SqlCommand(insertQueryCustomerBill, connection))
                                    {
                                        cmdCustomerBill.Parameters.AddWithValue("@ProductQty", productQty);
                                        cmdCustomerBill.Parameters.AddWithValue("@PaidAmount", paidAmount);
                                        cmdCustomerBill.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);
                                        cmdCustomerBill.Parameters.AddWithValue("@TotalAmount", totalAmount);
                                        cmdCustomerBill.Parameters.AddWithValue("@CustomerStockOutid", customerStockOutId);
                                        cmdCustomerBill.Parameters.AddWithValue("@Customerid", customer);
                                        cmdCustomerBill.Parameters.AddWithValue("@Date", date); // Change @Date to @Date


                                        int rowsAffectedCustomerBill = cmdCustomerBill.ExecuteNonQuery();
                                        if (rowsAffectedCustomerBill > 0)
                                        {
                                            MessageBox.Show("Product added to CustomerBill successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        }
                                        else
                                        {
                                            MessageBox.Show("Product could not be added to CustomerBill.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("CustomerStockOutid not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Product could not be added to CustomerStockOut.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void textTotalAmount_TextChanged(object sender, EventArgs e)
        {
            UpdateUnpaidAmount();
        }
        private void UpdateUnpaidAmount()
        {
            if (decimal.TryParse(textTotalAmount.Text, out decimal totalAmount) && decimal.TryParse(textPaid.Text, out decimal paidAmount))
            {
                decimal unpaidAmount = totalAmount - paidAmount;
                textUnpaidAmount.Text = unpaidAmount.ToString();
            }
            else
            {
                // Handle the case where the input is not valid (e.g., non-numeric values).
                textUnpaidAmount.Text = string.Empty;
            }
        }
        private void textUnpaidAmount_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textPaid_TextChanged(object sender, EventArgs e)
        {
            UpdateUnpaidAmount();
        }

        private void textSupProdQty_TextChanged(object sender, EventArgs e)
        {
            UpdateTotalAmount();
        }

        private void textSupProdPrice_TextChanged(object sender, EventArgs e)
        {
            UpdateTotalAmount();
        }
        private void DeleteRecordFromDatabase(int stockId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Delete records from CustomerBill table where Productid matches Stockid
                        string deleteBillQuery = "DELETE FROM CustomerBill WHERE Productid = @Productid";

                        using (SqlCommand cmdBill = new SqlCommand(deleteBillQuery, connection, transaction))
                        {
                            cmdBill.Parameters.AddWithValue("@Productid", stockId);
                            cmdBill.ExecuteNonQuery();
                        }

                        // Delete records from CustomerStockOut table
                        string deleteStockOutQuery = "DELETE FROM CustomerStockOut WHERE Productid = @Productid";

                        using (SqlCommand cmdStockOut = new SqlCommand(deleteStockOutQuery, connection, transaction))
                        {
                            cmdStockOut.Parameters.AddWithValue("@Productid", stockId);
                            cmdStockOut.ExecuteNonQuery();
                        }

                        // Commit the transaction if all statements succeed
                        transaction.Commit();
                        MessageBox.Show("Records deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // An error occurred, rollback the transaction
                        transaction.Rollback();
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }



            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Update foreign key references in CustomerBill table
                        string updateBillQuery = "UPDATE CustomerBill SET Productid = NULL WHERE Productid = @Productid";

                        using (SqlCommand cmdUpdateBill = new SqlCommand(updateBillQuery, connection, transaction))
                        {
                            cmdUpdateBill.Parameters.AddWithValue("@Productid", stockId);
                            cmdUpdateBill.ExecuteNonQuery();
                        }

                        // Delete records from CustomerStockOut table
                        string deleteStockOutQuery = "DELETE FROM CustomerStockOut WHERE Productid = @Productid";

                        using (SqlCommand cmdStockOut = new SqlCommand(deleteStockOutQuery, connection, transaction))
                        {
                            cmdStockOut.Parameters.AddWithValue("@Productid", stockId);
                            cmdStockOut.ExecuteNonQuery();
                        }

                        // Commit the transaction if all statements succeed
                        transaction.Commit();
                        MessageBox.Show("Records deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // An error occurred, rollback the transaction
                        transaction.Rollback();
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }







        }
        private void CustomerStockIn_Load(object sender, EventArgs e)
        {

        }
        private void LoadDataIntoDataGridView()
        {
            DataTable table = FetchDataFromDatabase();

            if (table != null)
            {
                DataGridviewProduct.DataSource = table;
            }
        }
        private DataTable FetchDataFromDatabase()
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM CompanyStockIn"; // Replace 'YourTableName' with your table name

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (DataGridviewProduct.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = DataGridviewProduct.SelectedRows[0];

                // Extract the data you need from the selected row, e.g., stock ID
                int stockId = Convert.ToInt32(selectedRow.Cells["Productid"].Value);

                // Prompt the user for confirmation
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    // Delete the record from the database
                    DeleteRecordFromDatabase(stockId);

                    // Remove the selected row from the DataGridView
                    DataGridviewProduct.Rows.Remove(selectedRow);
                }
            }
        }


      
        private void custdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = custdataGridView.Rows[e.RowIndex];

                // Assuming the column name for Customerid is "Customerid"
                string customerId = selectedRow.Cells["Customerid"].Value.ToString();
                Customer.Text = customerId;

                // Access other values as needed
                // string customerName = selectedRow.Cells["CustomerName"].Value.ToString();
                // string contactPerson = selectedRow.Cells["ContactPerson"].Value.ToString();
                // ... (access other cell values in a similar manner)
            }
        }

        private void Customer_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void DataGridviewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void SearchByProductName()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM CompanyStockIn WHERE ProductName LIKE @search";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@search", "%" + textProdSearch.Text + "%");

                    DataTable searchResultsDataTable = new DataTable();
                    adapter.Fill(searchResultsDataTable);

                    DataGridviewProduct.DataSource = searchResultsDataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SearchByCustomerName()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Customers WHERE CustomerName LIKE @search";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@search", "%" + textCustSearch.Text + "%");

                    DataTable searchResultsDataTable = new DataTable();
                    adapter.Fill(searchResultsDataTable);

                    custdataGridView.DataSource = searchResultsDataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Button click event for search

        private void Search_Click(object sender, EventArgs e)
        {
            SearchByProductName();
            SearchByCustomerName();
        }

        private void dataGridViewStockOut_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM CustomerStockOut";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable customerStockOutDataTable = new DataTable();
                    adapter.Fill(customerStockOutDataTable);

                    dataGridViewStockOut.DataSource = customerStockOutDataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Search_Update_Click(object sender, EventArgs e)
        {
            try
            {
                string customerStockId = textUpdateSearch.Text; // Get the CustomerStockId from the TextBox

                if (!string.IsNullOrEmpty(customerStockId))
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "SELECT * FROM CustomerStockOut WHERE CustomerStockOutId = @CustomerStockOutId";

                        SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                        adapter.SelectCommand.Parameters.AddWithValue("@CustomerStockOutId", customerStockId);

                        DataTable customerStockOutDataTable = new DataTable();
                        adapter.Fill(customerStockOutDataTable);

                        dataGridViewStockOut.DataSource = customerStockOutDataTable;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a CustomerStockId.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
