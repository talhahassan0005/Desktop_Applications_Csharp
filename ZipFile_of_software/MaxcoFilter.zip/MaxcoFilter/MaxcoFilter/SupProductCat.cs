﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class SupProductCat : Form
    {
        private string connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"; // Replace with your actual database connection string
        private DataTable categoriesDataTable;
        public SupProductCat()
        {
            InitializeComponent();
        }

        private void SupProductCat_Load(object sender, EventArgs e)
        {
            LoadCategories();
        }

        private void LoadCategories()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Catid, CatName, CatDescription FROM SupplierCategory";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                categoriesDataTable = new DataTable();
                adapter.Fill(categoriesDataTable);
                dataGridViewCat.DataSource = categoriesDataTable;
            }
        }

        private void btnAddCat_Click(object sender, EventArgs e)
        {
            string categoryName = textSuppcatName.Text;
            string categoryDescription = textSuppcatDescrip.Text;

            if (string.IsNullOrWhiteSpace(categoryName))
            {
                MessageBox.Show("Category Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO SupplierCategory (CatName, CatDescription) VALUES (@CategoryName, @CategoryDescription)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@CategoryName", categoryName);
                        cmd.Parameters.AddWithValue("@CategoryDescription", categoryDescription);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Category added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadCategories(); // Refresh the DataGridView
                            ClearFormFields();
                        }
                        else
                        {
                            MessageBox.Show("Category could not be added.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdateCat_Click(object sender, EventArgs e)
        {
            if (dataGridViewCat.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a category to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int selectedRowIndex = dataGridViewCat.SelectedRows[0].Index;
            int categoryId = Convert.ToInt32(dataGridViewCat.Rows[selectedRowIndex].Cells["Catid"].Value);
            string categoryName = textSuppcatName.Text;
            string categoryDescription = textSuppcatDescrip.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string updateQuery = "UPDATE SupplierCategory SET CatName = @CategoryName, CatDescription = @CategoryDescription WHERE Catid = @CategoryId";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@CategoryId", categoryId);
                        cmd.Parameters.AddWithValue("@CategoryName", categoryName);
                        cmd.Parameters.AddWithValue("@CategoryDescription", categoryDescription);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Category updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadCategories(); // Refresh the DataGridView
                            ClearFormFields();
                        }
                        else
                        {
                            MessageBox.Show("Category could not be updated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ClearFormFields()
        {
            textSuppcatName.Clear();
            textSuppcatDescrip.Clear();
        }
        private void btnDeleteCat_Click(object sender, EventArgs e)
        {
            if (dataGridViewCat.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a category to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int selectedRowIndex = dataGridViewCat.SelectedRows[0].Index;
            int categoryId = Convert.ToInt32(dataGridViewCat.Rows[selectedRowIndex].Cells["Catid"].Value);

            if (MessageBox.Show("Are you sure you want to delete this category?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string deleteQuery = "DELETE FROM SupplierCategory WHERE Catid = @CategoryId";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@CategoryId", categoryId);
                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Category deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadCategories(); // Refresh the DataGridView
                                ClearFormFields();
                            }
                            else
                            {
                                MessageBox.Show("Category could not be deleted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }



        }
    }
}
