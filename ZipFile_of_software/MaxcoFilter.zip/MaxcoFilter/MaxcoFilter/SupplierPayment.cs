﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class SupplierPayment : Form
    {
        private string connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"; 
        public SupplierPayment()
        {
            InitializeComponent();
            PaymentdataGridView.DataSource = FetchDataFromDatabase();
            LoadSupplierLegerData();
        }
        private void LoadSupplierLegerData()
        {
            try
            {
                string query = "SELECT * FROM SupplierPaymentLedger";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    SupplierLegerGridview.DataSource = dataTable; // Bind the data to the SupplierLegerGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PaymentdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void UpdateDatabaseRecord(int recordId, float payableAmount, float paidAmount)
        {
           
        }
        // Add a method to fetch data from the database
        private DataTable FetchDataFromDatabase()
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT s.Stockid, s.PayableAmount, s.PaidAmount, s.ProductQty, " +
                               "sp.SupplierName, sc.ProductName, sc.TotalAmount AS ProductTotalAmount, s.SupplierId " +
                               "FROM SupplierStockIn s " +
                               "LEFT JOIN Suppliers sp ON s.SupplierId = sp.SupplierId " +
                               "LEFT JOIN SupplierProduct sc ON s.ProductId = sc.ProductId";






                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        
       
        private void InsertRecordSupplierStockIn(int Productid, int ProductQty, int Supplierid, float paidAmount, float unpaidAmount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO SupplierStockIn (Productid,Supplierid, ProductQty, PaidAmount, PayableAmount) VALUES (@Productid,@Supplierid, @ProductQty, @PaidAmount, @PayableAmount)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Supplierid", Supplierid);
                    cmd.Parameters.AddWithValue("@Productid", Productid);
                    cmd.Parameters.AddWithValue("@ProductQty", ProductQty);
                    cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                    cmd.Parameters.AddWithValue("@PayableAmount", unpaidAmount);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record inserted into SupplierStockIn successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // You can optionally refresh the DataGridView or take other actions as needed
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert record into SupplierStockIn.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        int Prodid;
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textPaid.Text) && decimal.TryParse(textPaid.Text, out decimal paidAmount))
                {
                    if (PaymentdataGridView.SelectedRows.Count > 0)
                    {
                        DataGridViewRow selectedRow = PaymentdataGridView.SelectedRows[0];

                        if (selectedRow.Cells["Stockid"].Value != null &&
                            selectedRow.Cells["Supplierid"].Value != null &&
                            selectedRow.Cells["PayableAmount"].Value != null)
                        {
                            int stockId = Convert.ToInt32(selectedRow.Cells["Stockid"].Value);
                            int supplierId = Convert.ToInt32(selectedRow.Cells["Supplierid"].Value);
                            decimal totalAmount = Convert.ToDecimal(selectedRow.Cells["PayableAmount"].Value);
                            decimal remainingAmount = totalAmount - paidAmount;

                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                SqlTransaction transaction = connection.BeginTransaction();

                                try
                                {
                                    string updateQuery = "UPDATE SupplierStockIn SET PayableAmount = @RemainingAmount WHERE Stockid = @Stockid";

                                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, connection, transaction))
                                    {
                                        updateCmd.Parameters.AddWithValue("@RemainingAmount", remainingAmount);
                                        updateCmd.Parameters.AddWithValue("@Stockid", stockId);

                                        int rowsAffected = updateCmd.ExecuteNonQuery();

                                        if (rowsAffected > 0)
                                        {
                                            string insertLedgerQuery = "INSERT INTO SupplierPaymentLedger (SupplierId, PaidAmount, PayableAmount, TransactionDate) " +
                                                                       "VALUES (@SupplierId, @PaidAmount, @PayableAmount, @TransactionDate)";

                                            using (SqlCommand ledgerCmd = new SqlCommand(insertLedgerQuery, connection, transaction))
                                            {
                                                ledgerCmd.Parameters.AddWithValue("@SupplierId", supplierId);
                                                ledgerCmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                                                ledgerCmd.Parameters.AddWithValue("@PayableAmount", remainingAmount);
                                                ledgerCmd.Parameters.AddWithValue("@TransactionDate", dateTimePicker1.Value);

                                                int ledgerRowsAffected = ledgerCmd.ExecuteNonQuery();

                                                if (ledgerRowsAffected > 0)
                                                {
                                                    transaction.Commit();
                                                    MessageBox.Show("Payment recorded successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                }
                                                else
                                                {
                                                    transaction.Rollback();
                                                    MessageBox.Show("Failed to record payment in the ledger.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            transaction.Rollback();
                                            MessageBox.Show("Failed to update the payable amount in the 'SupplierStockIn' table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Selected row does not contain necessary data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record from the DataGridView.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric payment amount.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }



        private DataTable originalDataTable;
        private void SupplierPayment_Load_1(object sender, EventArgs e)
        {
            originalDataTable = FetchDataFromDatabase(); // Make sure to implement this method.

            // Set the DataGridView's data source to originalDataTable.
            PaymentdataGridView.DataSource = originalDataTable;
            PaymentdataGridView.DataSource = FetchDataFromDatabase();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                DataView dataView = originalDataTable.DefaultView;
                dataView.RowFilter = $"supplierName LIKE '%{textBox1.Text}%'"; // You can modify the filter condition as needed.
                PaymentdataGridView.DataSource = dataView.ToTable();
            }
            else
            {
                PaymentdataGridView.DataSource = originalDataTable; // Show all records when the filter text is empty.
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            PaymentdataGridView.DataSource = FetchDataFromDatabase();
            LoadSupplierLegerData();
        }

        private void textUnpaid_TextChanged(object sender, EventArgs e)
        {

        }

        private void textPaid_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (decimal.TryParse(textPaid.Text, out decimal paidAmount))
                {
                    if (PaymentdataGridView.SelectedRows.Count > 0)
                    {
                        DataGridViewRow selectedRow = PaymentdataGridView.SelectedRows[0];

                        if (selectedRow.Cells["PayableAmount"].Value != null && selectedRow.Cells["StockId"].Value != null)
                        {
                            decimal payableAmount = Convert.ToDecimal(selectedRow.Cells["PayableAmount"].Value);
                            decimal unpaidAmount = payableAmount - paidAmount;

                            // Update the text box with the new unpaid amount
                            textUnpaid.Text = unpaidAmount.ToString();
                        }
                    }
                }
                else
                {
                    // Clear the text box if the entered paid amount is not a valid decimal
                    textUnpaid.Text = "";
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that might occur
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void DeleteRecordFromDatabase(int stockId)
        {
            // Implement your database delete logic here
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM SupplierStockIn WHERE Stockid = @Stockid";
                using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Stockid", stockId);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        // Database deletion was successful
                        MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // Database deletion failed
                        MessageBox.Show("Failed to delete the record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (SupplierLegerGridview.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = SupplierLegerGridview.SelectedRows[0];

                    // Get the TransactionID from the first cell (assuming it's at index 0)
                    if (selectedRow.Cells[0].Value != null &&
                        int.TryParse(selectedRow.Cells[0].Value.ToString(), out int transactionID))
                    {
                        // Construct the SQL delete query
                        string deleteQuery = "DELETE FROM SupplierPaymentLedger WHERE TransectionID = @TransactionID";

                        // Execute the deletion
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@TransactionID", transactionID);
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LoadSupplierLegerData(); // Refresh data after deletion
                                }
                                else
                                {
                                    MessageBox.Show("Record deletion failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Unable to retrieve TransactionID from the selected row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void PaymentdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SupplierLegerGridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Your payment transaction code...

                // Refresh SupplierLegerGridView after successful transaction
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM SupplierPaymentLedger", connectionString);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                SupplierLegerGridview.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }
