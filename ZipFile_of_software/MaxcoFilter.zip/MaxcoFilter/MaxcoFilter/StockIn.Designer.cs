﻿namespace MaxcoFilter
{
    partial class StockIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textSuppplierName = new System.Windows.Forms.TextBox();
            this.textSupplierCity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SearchSupplier = new System.Windows.Forms.Button();
            this.StockInGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.StockInGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // textSuppplierName
            // 
            this.textSuppplierName.Location = new System.Drawing.Point(99, 25);
            this.textSuppplierName.Name = "textSuppplierName";
            this.textSuppplierName.Size = new System.Drawing.Size(154, 20);
            this.textSuppplierName.TabIndex = 0;
            this.textSuppplierName.TextChanged += new System.EventHandler(this.textSuppplierName_TextChanged);
            // 
            // textSupplierCity
            // 
            this.textSupplierCity.Location = new System.Drawing.Point(99, 68);
            this.textSupplierCity.Name = "textSupplierCity";
            this.textSupplierCity.Size = new System.Drawing.Size(154, 20);
            this.textSupplierCity.TabIndex = 1;
            this.textSupplierCity.TextChanged += new System.EventHandler(this.textSupplierCity_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Supplier_Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Supplier_City";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // SearchSupplier
            // 
            this.SearchSupplier.Location = new System.Drawing.Point(99, 116);
            this.SearchSupplier.Name = "SearchSupplier";
            this.SearchSupplier.Size = new System.Drawing.Size(75, 23);
            this.SearchSupplier.TabIndex = 3;
            this.SearchSupplier.Text = "Search";
            this.SearchSupplier.UseVisualStyleBackColor = true;
            this.SearchSupplier.Click += new System.EventHandler(this.SearchSupplier_Click);
            // 
            // StockInGrid
            // 
            this.StockInGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StockInGrid.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.StockInGrid.Location = new System.Drawing.Point(0, 239);
            this.StockInGrid.Name = "StockInGrid";
            this.StockInGrid.ReadOnly = true;
            this.StockInGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StockInGrid.Size = new System.Drawing.Size(898, 248);
            this.StockInGrid.TabIndex = 4;
            this.StockInGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StockInGrid_CellContentClick);
            // 
            // StockIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 487);
            this.Controls.Add(this.StockInGrid);
            this.Controls.Add(this.SearchSupplier);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textSupplierCity);
            this.Controls.Add(this.textSuppplierName);
            this.Name = "StockIn";
            this.Text = "StockIn";
            this.Load += new System.EventHandler(this.StockIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StockInGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textSuppplierName;
        private System.Windows.Forms.TextBox textSupplierCity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button SearchSupplier;
        private System.Windows.Forms.DataGridView StockInGrid;
    }
}