SELECT 
    FK.name AS ForeignKey,
    TP.name AS ParentTable,
    CP.name AS ParentColumn,
    TR.name AS ReferencedTable,
    CR.name AS ReferencedColumn,
    FK.delete_referential_action_desc AS DeleteAction
FROM sys.foreign_keys FK
INNER JOIN sys.tables TP ON FK.parent_object_id = TP.object_id
INNER JOIN sys.tables TR ON FK.referenced_object_id = TR.object_id
INNER JOIN sys.foreign_key_columns FKC ON FKC.constraint_object_id = FK.object_id
INNER JOIN sys.columns CP ON FKC.parent_column_id = CP.column_id AND FKC.parent_object_id = CP.object_id
INNER JOIN sys.columns CR ON FKC.referenced_column_id = CR.column_id AND FKC.referenced_object_id = CR.object_id
WHERE TP.name = 'SupplierProduct' AND TR.name = 'SupplierStockIn';
