﻿namespace MaxcoFilter
{
    partial class CustomerPaymentUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PaymentdataGridView = new System.Windows.Forms.DataGridView();
            this.textUnpaid = new System.Windows.Forms.TextBox();
            this.textPaid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewCustPayament = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SupplierPaymentLegers = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustPayament)).BeginInit();
            this.SuspendLayout();
            // 
            // PaymentdataGridView
            // 
            this.PaymentdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PaymentdataGridView.Location = new System.Drawing.Point(12, 152);
            this.PaymentdataGridView.Name = "PaymentdataGridView";
            this.PaymentdataGridView.ReadOnly = true;
            this.PaymentdataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PaymentdataGridView.Size = new System.Drawing.Size(607, 295);
            this.PaymentdataGridView.TabIndex = 11;
            this.PaymentdataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PaymentdataGridView_CellClick);
            this.PaymentdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PaymentdataGridView_CellContentClick);
            // 
            // textUnpaid
            // 
            this.textUnpaid.Location = new System.Drawing.Point(112, 69);
            this.textUnpaid.Name = "textUnpaid";
            this.textUnpaid.Size = new System.Drawing.Size(100, 20);
            this.textUnpaid.TabIndex = 9;
            this.textUnpaid.TextChanged += new System.EventHandler(this.textUnpaid_TextChanged);
            // 
            // textPaid
            // 
            this.textPaid.Location = new System.Drawing.Point(112, 32);
            this.textPaid.Name = "textPaid";
            this.textPaid.Size = new System.Drawing.Size(100, 20);
            this.textPaid.TabIndex = 10;
            this.textPaid.TextChanged += new System.EventHandler(this.textPaid_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Upaid_Amount";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Paid_Amount";
            // 
            // dataGridViewCustPayament
            // 
            this.dataGridViewCustPayament.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustPayament.Location = new System.Drawing.Point(643, 152);
            this.dataGridViewCustPayament.Name = "dataGridViewCustPayament";
            this.dataGridViewCustPayament.ReadOnly = true;
            this.dataGridViewCustPayament.Size = new System.Drawing.Size(362, 295);
            this.dataGridViewCustPayament.TabIndex = 12;
            this.dataGridViewCustPayament.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCustPayament_CellContentClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(24, 99);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(24, 6);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 17;
            // 
            // SupplierPaymentLegers
            // 
            this.SupplierPaymentLegers.AutoSize = true;
            this.SupplierPaymentLegers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SupplierPaymentLegers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SupplierPaymentLegers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierPaymentLegers.Location = new System.Drawing.Point(779, 128);
            this.SupplierPaymentLegers.Name = "SupplierPaymentLegers";
            this.SupplierPaymentLegers.Size = new System.Drawing.Size(182, 18);
            this.SupplierPaymentLegers.TabIndex = 21;
            this.SupplierPaymentLegers.Text = "CustomerPaymentLegers";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(698, 125);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 20;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(493, 97);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 19;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(493, 123);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(75, 23);
            this.txtSearch.TabIndex = 18;
            this.txtSearch.Text = "Search";
            this.txtSearch.UseVisualStyleBackColor = true;
            this.txtSearch.Click += new System.EventHandler(this.txtSearch_Click);
            // 
            // CustomerPaymentUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 469);
            this.Controls.Add(this.SupplierPaymentLegers);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridViewCustPayament);
            this.Controls.Add(this.PaymentdataGridView);
            this.Controls.Add(this.textUnpaid);
            this.Controls.Add(this.textPaid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CustomerPaymentUpdate";
            this.Text = "CustomerPaymentUpdate";
            this.Load += new System.EventHandler(this.CustomerPaymentUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PaymentdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustPayament)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView PaymentdataGridView;
        private System.Windows.Forms.TextBox textUnpaid;
        private System.Windows.Forms.TextBox textPaid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewCustPayament;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label SupplierPaymentLegers;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button txtSearch;
    }
}