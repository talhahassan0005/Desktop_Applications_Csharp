﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class StockIn : Form
    {
        string connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";
        public StockIn()
        {
            InitializeComponent();
            StockInGrid.DataSource = FetchSuppliersFromDatabase();
        }
        private void SearchSuppliers(string name, string city)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Suppliers WHERE 1=1"; // Initialize query with true condition

                // Check if the user provided a name filter
                if (!string.IsNullOrEmpty(name))
                {
                    query += " AND SupplierName LIKE @nameFilter";
                }

                // Check if the user provided a city filter
                if (!string.IsNullOrEmpty(city))
                {
                    query += " AND SupplierCity LIKE @cityFilter";
                }

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    if (!string.IsNullOrEmpty(name))
                    {
                        cmd.Parameters.AddWithValue("@nameFilter", "%" + name + "%");
                    }

                    if (!string.IsNullOrEmpty(city))
                    {
                        cmd.Parameters.AddWithValue("@cityFilter", "%" + city + "%");
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    StockInGrid.DataSource = suppliersDataTable;
                }
            }
        }
        private void SearchSupplier_Click(object sender, EventArgs e)
        {
            string nameFilter = textSuppplierName.Text.Trim();
            string cityFilter = textSupplierCity.Text.Trim();
            SearchSuppliers(nameFilter, cityFilter);
        }

        private DataTable FetchSuppliersFromDatabase()
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Suppliers"; // Adjust the query to your table's schema
                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        private void StockIn_Load(object sender, EventArgs e)
        {

        }

        private void textSupplierCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textSuppplierName_TextChanged(object sender, EventArgs e)
        {

        }

        private void StockInGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


       
        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
        }

        private void UpdateRecordInDatabase(int stockId, float newPayableAmount)
        {
           
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
          
            

        }
    }
}
