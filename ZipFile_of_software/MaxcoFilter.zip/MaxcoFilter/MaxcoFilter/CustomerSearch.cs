﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class CustomerSearch : Form
    {
        public CustomerSearch()
        {
            InitializeComponent();
            LoadAllCustomers();
        }

        private void SearchSuppliers(string name, string city)
        {
            using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"))
            {
                connection.Open();
                string query = "SELECT * FROM Customers WHERE 1=1"; // Initialize query with true condition

                // Check if the user provided a name filter
                if (!string.IsNullOrEmpty(name))
                {
                    query += " AND CustomerName LIKE @nameFilter";
                }

                // Check if the user provided a city filter
                if (!string.IsNullOrEmpty(city))
                {
                    query += " AND CustomerCity LIKE @cityFilter";
                }

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    if (!string.IsNullOrEmpty(name))
                    {
                        cmd.Parameters.AddWithValue("@nameFilter", "%" + name + "%");
                    }

                    if (!string.IsNullOrEmpty(city))
                    {
                        cmd.Parameters.AddWithValue("@cityFilter", "%" + city + "%");
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    StockInGrid.DataSource = suppliersDataTable;
                }
            }
        }
        private void SearchSupplier_Click(object sender, EventArgs e)
        {
            string nameFilter = textCustomerName.Text.Trim();
            string cityFilter = textCustomerCity.Text.Trim();
            SearchSuppliers(nameFilter, cityFilter);
        }
        private void LoadAllCustomers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog=MaxcoFilter;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"))
                {
                    connection.Open();
                    string query = "SELECT * FROM Customers"; // Query to select all data from the 'Suppliers' table

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    StockInGrid.DataSource = suppliersDataTable; // Bind the data to the DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void StockInGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
