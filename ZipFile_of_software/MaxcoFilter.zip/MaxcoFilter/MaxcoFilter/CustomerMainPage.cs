﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class CustomerMainPage : Form
    {
        public CustomerMainPage()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CustCategories supplierStockoutForm = new CustCategories();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BigMainPage mainForm = new BigMainPage(); // Replace "MainForm" with the actual name of your main form
            mainForm.Show();
            this.Close(); // Close the current form
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CustomerStockIn supplierStockoutForm = new CustomerStockIn();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            Customers supplierStockoutForm = new Customers();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CustomerSearch supplierStockoutForm = new CustomerSearch();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CustomerPaymentUpdate supplierStockoutForm = new CustomerPaymentUpdate();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CompanyStockIn supplierStockoutForm = new CompanyStockIn();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            CustomerReport supplierStockoutForm = new CustomerReport();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();

        }
    }
    
}
