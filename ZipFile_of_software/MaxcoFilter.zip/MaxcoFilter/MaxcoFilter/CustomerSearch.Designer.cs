﻿namespace MaxcoFilter
{
    partial class CustomerSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StockInGrid = new System.Windows.Forms.DataGridView();
            this.SearchSupplier = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textCustomerCity = new System.Windows.Forms.TextBox();
            this.textCustomerName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.StockInGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // StockInGrid
            // 
            this.StockInGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StockInGrid.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.StockInGrid.Location = new System.Drawing.Point(0, 139);
            this.StockInGrid.Name = "StockInGrid";
            this.StockInGrid.ReadOnly = true;
            this.StockInGrid.Size = new System.Drawing.Size(1003, 248);
            this.StockInGrid.TabIndex = 10;
            this.StockInGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StockInGrid_CellContentClick);
            // 
            // SearchSupplier
            // 
            this.SearchSupplier.Location = new System.Drawing.Point(99, 103);
            this.SearchSupplier.Name = "SearchSupplier";
            this.SearchSupplier.Size = new System.Drawing.Size(75, 23);
            this.SearchSupplier.TabIndex = 9;
            this.SearchSupplier.Text = "Search";
            this.SearchSupplier.UseVisualStyleBackColor = true;
            this.SearchSupplier.Click += new System.EventHandler(this.SearchSupplier_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Customer_City";
            // 
            // textCustomerCity
            // 
            this.textCustomerCity.Location = new System.Drawing.Point(99, 55);
            this.textCustomerCity.Name = "textCustomerCity";
            this.textCustomerCity.Size = new System.Drawing.Size(154, 20);
            this.textCustomerCity.TabIndex = 6;
            // 
            // textCustomerName
            // 
            this.textCustomerName.Location = new System.Drawing.Point(99, 12);
            this.textCustomerName.Name = "textCustomerName";
            this.textCustomerName.Size = new System.Drawing.Size(154, 20);
            this.textCustomerName.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Customer_Name";
            // 
            // CustomerSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 387);
            this.Controls.Add(this.StockInGrid);
            this.Controls.Add(this.SearchSupplier);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textCustomerCity);
            this.Controls.Add(this.textCustomerName);
            this.Name = "CustomerSearch";
            this.Text = "CustomerSearch";
            ((System.ComponentModel.ISupportInitialize)(this.StockInGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView StockInGrid;
        private System.Windows.Forms.Button SearchSupplier;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textCustomerCity;
        private System.Windows.Forms.TextBox textCustomerName;
        private System.Windows.Forms.Label label1;
    }
}