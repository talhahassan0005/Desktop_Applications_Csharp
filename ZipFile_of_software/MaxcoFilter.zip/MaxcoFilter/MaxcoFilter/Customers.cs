﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
            LoadAllCustomers();
        }
        private void ClearSupplierFormFields()
        {
            textCustName.Clear();
            textCustContPerson.Clear();
            textCustContact.Clear();
            textCustAddress.Clear();
            textCustCity.Clear();
            textCustEmail.Clear();
        }
        private void BtnSuppSave_Click(object sender, EventArgs e)
        {
            string CustomerName = textCustName.Text;
            string contactPerson = textCustContPerson.Text;
            string CustomerContact = textCustContact.Text;
            string CustomerAddress = textCustAddress.Text;
            string CustomerCity = textCustCity.Text;
            string CustomerEmail = textCustEmail.Text;

            if (string.IsNullOrEmpty(CustomerName) || string.IsNullOrEmpty(CustomerCity))
            {
                MessageBox.Show("CustomerName and CustomerCity are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"))
                {
                    connection.Open();
                    string query = "INSERT INTO Customers (CustomerName, ContactPerson, CustomerContact, CustomerAddress, CustomerCity,CustomerEmail) " +
                                   "VALUES (@CustomerName, @ContactPerson, @CustomerContact, @CustomerAddress, @CustomerCity, @CustomerEmail)";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@CustomerName", CustomerName);
                        cmd.Parameters.AddWithValue("@ContactPerson", contactPerson);
                        cmd.Parameters.AddWithValue("@CustomerContact", CustomerContact);
                        cmd.Parameters.AddWithValue("@CustomerAddress", CustomerAddress);
                        cmd.Parameters.AddWithValue("@CustomerCity", CustomerCity);
                        cmd.Parameters.AddWithValue("@CustomerEmail", CustomerEmail);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Customer information saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearSupplierFormFields();
                            LoadAllCustomers();
                        }
                        else
                        {
                            MessageBox.Show("Customer information could not be saved.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadAllCustomers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog=MaxcoFilter;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"))
                {
                    connection.Open();
                    string query = "SELECT * FROM Customers"; // Query to select all data from the 'Suppliers' table

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    dataGridView1.DataSource = suppliersDataTable; // Bind the data to the DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Assuming the SupplierID is in the first column (index 0), replace this with the actual index
                    int supplierID = Convert.ToInt32(selectedRow.Cells[0].Value);

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this Customers?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog=MaxcoFilter;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"))
                        {
                            connection.Open();

                            string deleteQuery = "DELETE FROM Customers WHERE Customerid = @Customerid";

                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@Customerid", supplierID);

                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Customer deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    // Refresh DataGridView after deletion
                                    LoadAllCustomers(); // Call the method that loads data into DataGridView
                                }
                                else
                                {
                                    MessageBox.Show("Customers deletion failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"))
                {
                    connection.Open();
                    string query = "SELECT * FROM Customers"; // Query to select all data from the 'Suppliers' table

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    dataGridView1.DataSource = suppliersDataTable; // Bind the data to the DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
