﻿using GLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class MaxcoStockIn : Form
    {
        private string connectionString = "data source = USER; initial catalog = MaxcoFilter_BackUp; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework";
        public MaxcoStockIn()
        {
            InitializeComponent();
            DisplayAllRecords();
         
        }

      

        private void DisplayAllRecords()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM ProductStockIn";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MaxcoStockIn_Load(object sender, EventArgs e)
        {

        }
    }
}
