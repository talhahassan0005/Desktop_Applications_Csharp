﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class SupplierStockOut : Form
    {
        String connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";
        public SupplierStockOut()
        {
            InitializeComponent();
            dataGridView.DataSource = FetchDataFromDatabase();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView.Rows[e.RowIndex];
                string existingQuantity = selectedRow.Cells["ProductQty"].Value.ToString();
                textQty.Text = existingQuantity;
            }
        }
        private DataTable FetchDataFromDatabase()
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SP.*, S.SupplierName, PC.CatName " +
                               "FROM SupplierProduct SP " +
                               "INNER JOIN Suppliers S ON SP.SupplierId = S.SupplierId " +
                               "INNER JOIN SupplierCategory PC ON SP.ProductCategory = PC.Catid";





                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;

        }

        private void LoadDataIntoDataGridView()
        {
            dataGridView.DataSource = FetchDataFromDatabase();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (dataGridView.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView.SelectedRows[0];
                string newQuantity = textQty.Text;

                if (int.TryParse(newQuantity, out int updatedQuantity))
                {
                    // Retrieve the product ID from the selected row
                    int productId = Convert.ToInt32(selectedRow.Cells["ProductId"].Value);

                    // Subtract the given quantity from the "SupplierProduct" table in your database
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string updateQuery = "UPDATE SupplierProduct SET ProductQty = ProductQty - @updatedQuantity WHERE ProductId = @ProductId";
                        using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@updatedQuantity", updatedQuantity);
                            cmd.Parameters.AddWithValue("@ProductId", productId);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("StockOut successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Proceed with inserting the record into "SupplierStockOut" table
                                string productName = selectedRow.Cells["ProductName"].Value.ToString();
                                string productDescription = selectedRow.Cells["ProductDescription"].Value.ToString();
                                float productPrice = Convert.ToSingle(selectedRow.Cells["ProductPrice"].Value);
                                string unit = selectedRow.Cells["Unit"].Value.ToString();
                                int productCategory = Convert.ToInt32(selectedRow.Cells["ProductCategory"].Value);
                                string supplierName = selectedRow.Cells["SupplierName"].Value.ToString();

                                // Retrieve the current date and time
                                DateTime currentDate = DateTime.Now;

                                string insertQuery = "INSERT INTO SupplierStockOut (ProductName, ProductDescription, ProductPrice, Unit, ProductCategory, ProductQuantity, SupplierName, Date) " +
                                                    "VALUES (@ProductName, @ProductDescription, @ProductPrice, @Unit, @ProductCategory, @ProductQuantity, @SupplierName, @Date)";
                                using (SqlCommand insertCmd = new SqlCommand(insertQuery, connection))
                                {
                                    insertCmd.Parameters.AddWithValue("@ProductName", productName);
                                    insertCmd.Parameters.AddWithValue("@ProductDescription", productDescription);
                                    insertCmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                                    insertCmd.Parameters.AddWithValue("@Unit", unit);
                                    insertCmd.Parameters.AddWithValue("@ProductCategory", productCategory);
                                    insertCmd.Parameters.AddWithValue("@ProductQuantity", updatedQuantity);
                                    insertCmd.Parameters.AddWithValue("@SupplierName", supplierName);
                                    insertCmd.Parameters.AddWithValue("@Date", currentDate); // Set the value for DateAdded parameter

                                    int rowsInserted = insertCmd.ExecuteNonQuery();
                                    if (rowsInserted > 0)
                                    {
                                        MessageBox.Show("Stock-out record saved to 'SupplierStockOut' table.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        // Refresh the DataGridView to reflect the changes
                                        LoadDataIntoDataGridView();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Failed to save the stock-out record to 'SupplierStockOut' table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("StockOut Failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a record from the DataGridView.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SupplierStockOut_Load(object sender, EventArgs e)
        {

        }
    }
}