﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class Form1 : Form
    {
       string connectionString = "data source=USER;initial catalog=MaxcoFilter_BackUp;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";
        public Form1()
        {
            InitializeComponent();
            LoadAllSuppliers();
        }
        private void ClearSupplierFormFields()
        {
            textSuppName.Clear();
            textContPerson.Clear();
            textSuppContact.Clear();
            textSuppAddress.Clear();
            textSuppCity.Clear();
            textSuppEmail.Clear();
        }

        private void BtnSuppSave_Click(object sender, EventArgs e)
        {
            string supplierName = textSuppName.Text;
            string contactPerson = textContPerson.Text;
            string supplierContact = textSuppContact.Text;
            string supplierAddress = textSuppAddress.Text;
            string supplierCity = textSuppCity.Text;
            string supplierEmail = textSuppEmail.Text;

            if (string.IsNullOrEmpty(supplierName) || string.IsNullOrEmpty(supplierCity))
            {
                MessageBox.Show("SupplierName and SupplierCity are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Suppliers (SupplierName, ContactPerson, Contact, SupplierAddress, SupplierCity, SupplierEmail) " +
                                   "VALUES (@SupplierName, @ContactPerson, @Contact, @SupplierAddress, @SupplierCity, @SupplierEmail)";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@SupplierName", supplierName);
                        cmd.Parameters.AddWithValue("@ContactPerson", contactPerson);
                        cmd.Parameters.AddWithValue("@Contact", supplierContact);
                        cmd.Parameters.AddWithValue("@SupplierAddress", supplierAddress);
                        cmd.Parameters.AddWithValue("@SupplierCity", supplierCity);
                        cmd.Parameters.AddWithValue("@SupplierEmail", supplierEmail);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Supplier information saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearSupplierFormFields();
                        }
                        else
                        {
                            MessageBox.Show("Supplier information could not be saved.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textSuppName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textContPerson_TextChanged(object sender, EventArgs e)
        {

        }

        private void textSuppContact_TextChanged(object sender, EventArgs e)
        {

        }

        private void textSuppAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void textSuppCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void textSuppEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Suppliers"; // Query to select all data from the 'Suppliers' table

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    dataGridView1.DataSource = suppliersDataTable; // Bind the data to the DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void LoadAllSuppliers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Suppliers"; // Query to select all data from the 'Suppliers' table

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable suppliersDataTable = new DataTable();
                    adapter.Fill(suppliersDataTable);
                    dataGridView1.DataSource = suppliersDataTable; // Bind the data to the DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    // Assuming the SupplierID is in the first column (index 0), replace this with the actual index
                    int supplierID = Convert.ToInt32(selectedRow.Cells[0].Value);

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this supplier?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog=MaxcoFilter;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework"))
                        {
                            connection.Open();

                            string deleteQuery = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";

                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@SupplierID", supplierID);

                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Supplier deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    // Refresh DataGridView after deletion
                                    LoadAllSuppliers(); // Call the method that loads data into DataGridView
                                }
                                else
                                {
                                    MessageBox.Show("Supplier deletion failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
