﻿namespace MaxcoFilter
{
    partial class SupplierProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textSupProd = new System.Windows.Forms.TextBox();
            this.textSupProdDes = new System.Windows.Forms.TextBox();
            this.textSupProdQty = new System.Windows.Forms.TextBox();
            this.textSupProdPrice = new System.Windows.Forms.TextBox();
            this.textSupProdUnit = new System.Windows.Forms.TextBox();
            this.comboSupCate = new System.Windows.Forms.ComboBox();
            this.DataGridviewProduct = new System.Windows.Forms.DataGridView();
            this.btnADD = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textTotalAmount = new System.Windows.Forms.TextBox();
            this.textPaid = new System.Windows.Forms.TextBox();
            this.textUnpaidAmount = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comSupplier = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SearchProduct = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridviewProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ProductName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Unit_Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Unit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Category";
            // 
            // textSupProd
            // 
            this.textSupProd.Location = new System.Drawing.Point(130, 48);
            this.textSupProd.Name = "textSupProd";
            this.textSupProd.Size = new System.Drawing.Size(200, 20);
            this.textSupProd.TabIndex = 1;
            // 
            // textSupProdDes
            // 
            this.textSupProdDes.Location = new System.Drawing.Point(130, 83);
            this.textSupProdDes.Name = "textSupProdDes";
            this.textSupProdDes.Size = new System.Drawing.Size(200, 20);
            this.textSupProdDes.TabIndex = 2;
            // 
            // textSupProdQty
            // 
            this.textSupProdQty.Location = new System.Drawing.Point(130, 118);
            this.textSupProdQty.Name = "textSupProdQty";
            this.textSupProdQty.Size = new System.Drawing.Size(200, 20);
            this.textSupProdQty.TabIndex = 3;
            this.textSupProdQty.TextChanged += new System.EventHandler(this.textSupProdQty_TextChanged);
            // 
            // textSupProdPrice
            // 
            this.textSupProdPrice.Location = new System.Drawing.Point(130, 143);
            this.textSupProdPrice.Name = "textSupProdPrice";
            this.textSupProdPrice.Size = new System.Drawing.Size(200, 20);
            this.textSupProdPrice.TabIndex = 4;
            this.textSupProdPrice.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textSupProdUnit
            // 
            this.textSupProdUnit.Location = new System.Drawing.Point(130, 176);
            this.textSupProdUnit.Name = "textSupProdUnit";
            this.textSupProdUnit.Size = new System.Drawing.Size(200, 20);
            this.textSupProdUnit.TabIndex = 5;
            // 
            // comboSupCate
            // 
            this.comboSupCate.FormattingEnabled = true;
            this.comboSupCate.Location = new System.Drawing.Point(130, 209);
            this.comboSupCate.Name = "comboSupCate";
            this.comboSupCate.Size = new System.Drawing.Size(121, 21);
            this.comboSupCate.TabIndex = 2;
            this.comboSupCate.SelectedIndexChanged += new System.EventHandler(this.comboSupCate_SelectedIndexChanged);
            // 
            // DataGridviewProduct
            // 
            this.DataGridviewProduct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DataGridviewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridviewProduct.Location = new System.Drawing.Point(347, 129);
            this.DataGridviewProduct.Name = "DataGridviewProduct";
            this.DataGridviewProduct.ReadOnly = true;
            this.DataGridviewProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridviewProduct.Size = new System.Drawing.Size(746, 331);
            this.DataGridviewProduct.TabIndex = 3;
            this.DataGridviewProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridviewProduct_CellContentClick);
            // 
            // btnADD
            // 
            this.btnADD.Location = new System.Drawing.Point(7, 421);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(75, 23);
            this.btnADD.TabIndex = 8;
            this.btnADD.Text = "ADD";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(106, 421);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 296);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Total-Amount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 325);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Paid-Amount";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 351);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "UnPaid-Amount";
            // 
            // textTotalAmount
            // 
            this.textTotalAmount.Location = new System.Drawing.Point(130, 296);
            this.textTotalAmount.Name = "textTotalAmount";
            this.textTotalAmount.ReadOnly = true;
            this.textTotalAmount.Size = new System.Drawing.Size(121, 20);
            this.textTotalAmount.TabIndex = 7;
            this.textTotalAmount.TextChanged += new System.EventHandler(this.textTotalAmount_TextChanged);
            // 
            // textPaid
            // 
            this.textPaid.Location = new System.Drawing.Point(130, 322);
            this.textPaid.Name = "textPaid";
            this.textPaid.Size = new System.Drawing.Size(121, 20);
            this.textPaid.TabIndex = 6;
            this.textPaid.TextChanged += new System.EventHandler(this.textPaid_TextChanged);
            // 
            // textUnpaidAmount
            // 
            this.textUnpaidAmount.Location = new System.Drawing.Point(130, 348);
            this.textUnpaidAmount.Name = "textUnpaidAmount";
            this.textUnpaidAmount.ReadOnly = true;
            this.textUnpaidAmount.Size = new System.Drawing.Size(121, 20);
            this.textUnpaidAmount.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 249);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Supplier";
            // 
            // comSupplier
            // 
            this.comSupplier.FormattingEnabled = true;
            this.comSupplier.Location = new System.Drawing.Point(130, 249);
            this.comSupplier.Name = "comSupplier";
            this.comSupplier.Size = new System.Drawing.Size(121, 21);
            this.comSupplier.TabIndex = 9;
            this.comSupplier.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(18, 388);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 10;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // SearchProduct
            // 
            this.SearchProduct.Location = new System.Drawing.Point(347, 103);
            this.SearchProduct.Name = "SearchProduct";
            this.SearchProduct.Size = new System.Drawing.Size(144, 20);
            this.SearchProduct.TabIndex = 11;
            this.SearchProduct.Text = "Search";
            this.SearchProduct.TextChanged += new System.EventHandler(this.SearchProduct_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(199, 421);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click_1);
            // 
            // SupplierProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 515);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.SearchProduct);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comSupplier);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textUnpaidAmount);
            this.Controls.Add(this.textPaid);
            this.Controls.Add(this.textTotalAmount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnADD);
            this.Controls.Add(this.DataGridviewProduct);
            this.Controls.Add(this.comboSupCate);
            this.Controls.Add(this.textSupProdUnit);
            this.Controls.Add(this.textSupProdPrice);
            this.Controls.Add(this.textSupProdQty);
            this.Controls.Add(this.textSupProdDes);
            this.Controls.Add(this.textSupProd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SupplierProduct";
            this.Text = "SupplierProduct";
            this.Load += new System.EventHandler(this.SupplierProduct_Load);
            this.Click += new System.EventHandler(this.SupplierProduct_Click);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridviewProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textSupProd;
        private System.Windows.Forms.TextBox textSupProdDes;
        private System.Windows.Forms.TextBox textSupProdQty;
        private System.Windows.Forms.TextBox textSupProdPrice;
        private System.Windows.Forms.TextBox textSupProdUnit;
        private System.Windows.Forms.ComboBox comboSupCate;
        private System.Windows.Forms.DataGridView DataGridviewProduct;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textTotalAmount;
        private System.Windows.Forms.TextBox textPaid;
        private System.Windows.Forms.TextBox textUnpaidAmount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comSupplier;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox SearchProduct;
        private System.Windows.Forms.Button btnDelete;
    }
}