﻿namespace MaxcoFilter
{
    partial class CustomerStockIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textUnpaidAmount = new System.Windows.Forms.TextBox();
            this.textPaid = new System.Windows.Forms.TextBox();
            this.textTotalAmount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.DataGridviewProduct = new System.Windows.Forms.DataGridView();
            this.comboSupCate = new System.Windows.Forms.ComboBox();
            this.textSupProdUnit = new System.Windows.Forms.TextBox();
            this.textSupProdPrice = new System.Windows.Forms.TextBox();
            this.textSupProdQty = new System.Windows.Forms.TextBox();
            this.textSupProdDes = new System.Windows.Forms.TextBox();
            this.textSupProd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.custdataGridView = new System.Windows.Forms.DataGridView();
            this.Customer = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewStockOut = new System.Windows.Forms.DataGridView();
            this.textProdSearch = new System.Windows.Forms.TextBox();
            this.textCustSearch = new System.Windows.Forms.TextBox();
            this.textUpdateSearch = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            this.Search_Update = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridviewProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStockOut)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(123, 363);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 34;
            // 
            // textUnpaidAmount
            // 
            this.textUnpaidAmount.Location = new System.Drawing.Point(123, 327);
            this.textUnpaidAmount.Name = "textUnpaidAmount";
            this.textUnpaidAmount.ReadOnly = true;
            this.textUnpaidAmount.Size = new System.Drawing.Size(121, 20);
            this.textUnpaidAmount.TabIndex = 29;
            this.textUnpaidAmount.TextChanged += new System.EventHandler(this.textUnpaidAmount_TextChanged);
            // 
            // textPaid
            // 
            this.textPaid.Location = new System.Drawing.Point(123, 301);
            this.textPaid.Name = "textPaid";
            this.textPaid.Size = new System.Drawing.Size(121, 20);
            this.textPaid.TabIndex = 27;
            this.textPaid.TextChanged += new System.EventHandler(this.textPaid_TextChanged);
            // 
            // textTotalAmount
            // 
            this.textTotalAmount.Location = new System.Drawing.Point(123, 275);
            this.textTotalAmount.Name = "textTotalAmount";
            this.textTotalAmount.ReadOnly = true;
            this.textTotalAmount.Size = new System.Drawing.Size(121, 20);
            this.textTotalAmount.TabIndex = 28;
            this.textTotalAmount.TextChanged += new System.EventHandler(this.textTotalAmount_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 369);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "UnPaid";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Total-Amount";
            // 
            // DataGridviewProduct
            // 
            this.DataGridviewProduct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DataGridviewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridviewProduct.Location = new System.Drawing.Point(339, 39);
            this.DataGridviewProduct.Name = "DataGridviewProduct";
            this.DataGridviewProduct.ReadOnly = true;
            this.DataGridviewProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridviewProduct.Size = new System.Drawing.Size(762, 133);
            this.DataGridviewProduct.TabIndex = 21;
            this.DataGridviewProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridviewProduct_CellContentClick);
            // 
            // comboSupCate
            // 
            this.comboSupCate.FormattingEnabled = true;
            this.comboSupCate.Location = new System.Drawing.Point(123, 239);
            this.comboSupCate.Name = "comboSupCate";
            this.comboSupCate.Size = new System.Drawing.Size(121, 21);
            this.comboSupCate.TabIndex = 19;
            // 
            // textSupProdUnit
            // 
            this.textSupProdUnit.Location = new System.Drawing.Point(123, 206);
            this.textSupProdUnit.Name = "textSupProdUnit";
            this.textSupProdUnit.Size = new System.Drawing.Size(200, 20);
            this.textSupProdUnit.TabIndex = 24;
            // 
            // textSupProdPrice
            // 
            this.textSupProdPrice.Location = new System.Drawing.Point(123, 173);
            this.textSupProdPrice.Name = "textSupProdPrice";
            this.textSupProdPrice.Size = new System.Drawing.Size(200, 20);
            this.textSupProdPrice.TabIndex = 22;
            this.textSupProdPrice.TextChanged += new System.EventHandler(this.textSupProdPrice_TextChanged);
            // 
            // textSupProdQty
            // 
            this.textSupProdQty.Location = new System.Drawing.Point(123, 148);
            this.textSupProdQty.Name = "textSupProdQty";
            this.textSupProdQty.Size = new System.Drawing.Size(200, 20);
            this.textSupProdQty.TabIndex = 20;
            this.textSupProdQty.TextChanged += new System.EventHandler(this.textSupProdQty_TextChanged);
            // 
            // textSupProdDes
            // 
            this.textSupProdDes.Location = new System.Drawing.Point(123, 113);
            this.textSupProdDes.Name = "textSupProdDes";
            this.textSupProdDes.Size = new System.Drawing.Size(200, 20);
            this.textSupProdDes.TabIndex = 18;
            // 
            // textSupProd
            // 
            this.textSupProd.Location = new System.Drawing.Point(123, 78);
            this.textSupProd.Name = "textSupProd";
            this.textSupProd.Size = new System.Drawing.Size(200, 20);
            this.textSupProd.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Category";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Unit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Unit_Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Quantity";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "ProductName";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(15, 448);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 31;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 304);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Paid";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 485);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 35;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // custdataGridView
            // 
            this.custdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.custdataGridView.Location = new System.Drawing.Point(339, 178);
            this.custdataGridView.Name = "custdataGridView";
            this.custdataGridView.ReadOnly = true;
            this.custdataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.custdataGridView.Size = new System.Drawing.Size(762, 150);
            this.custdataGridView.TabIndex = 36;
            this.custdataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.custdataGridView_CellClick);
            // 
            // Customer
            // 
            this.Customer.Location = new System.Drawing.Point(123, 407);
            this.Customer.Name = "Customer";
            this.Customer.Size = new System.Drawing.Size(100, 20);
            this.Customer.TabIndex = 37;
            this.Customer.TextChanged += new System.EventHandler(this.Customer_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 413);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = "Customer";
            // 
            // dataGridViewStockOut
            // 
            this.dataGridViewStockOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStockOut.Location = new System.Drawing.Point(339, 366);
            this.dataGridViewStockOut.Name = "dataGridViewStockOut";
            this.dataGridViewStockOut.ReadOnly = true;
            this.dataGridViewStockOut.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStockOut.Size = new System.Drawing.Size(762, 150);
            this.dataGridViewStockOut.TabIndex = 39;
            this.dataGridViewStockOut.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewStockOut_CellContentClick);
            // 
            // textProdSearch
            // 
            this.textProdSearch.Location = new System.Drawing.Point(1001, 15);
            this.textProdSearch.Name = "textProdSearch";
            this.textProdSearch.Size = new System.Drawing.Size(100, 20);
            this.textProdSearch.TabIndex = 40;
            this.textProdSearch.Text = "Search_Product";
            // 
            // textCustSearch
            // 
            this.textCustSearch.Location = new System.Drawing.Point(814, 14);
            this.textCustSearch.Name = "textCustSearch";
            this.textCustSearch.Size = new System.Drawing.Size(100, 20);
            this.textCustSearch.TabIndex = 41;
            this.textCustSearch.Text = "Search_Customer";
            // 
            // textUpdateSearch
            // 
            this.textUpdateSearch.Location = new System.Drawing.Point(994, 340);
            this.textUpdateSearch.Name = "textUpdateSearch";
            this.textUpdateSearch.Size = new System.Drawing.Size(100, 20);
            this.textUpdateSearch.TabIndex = 42;
            this.textUpdateSearch.Text = "Search by StockID";
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(724, 12);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(75, 23);
            this.Search.TabIndex = 43;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // Search_Update
            // 
            this.Search_Update.Location = new System.Drawing.Point(913, 340);
            this.Search_Update.Name = "Search_Update";
            this.Search_Update.Size = new System.Drawing.Size(75, 23);
            this.Search_Update.TabIndex = 44;
            this.Search_Update.Text = "Search";
            this.Search_Update.UseVisualStyleBackColor = true;
            this.Search_Update.Click += new System.EventHandler(this.Search_Update_Click);
            // 
            // CustomerStockIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 520);
            this.Controls.Add(this.Search_Update);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.textUpdateSearch);
            this.Controls.Add(this.textCustSearch);
            this.Controls.Add(this.textProdSearch);
            this.Controls.Add(this.dataGridViewStockOut);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Customer);
            this.Controls.Add(this.custdataGridView);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textUnpaidAmount);
            this.Controls.Add(this.textPaid);
            this.Controls.Add(this.textTotalAmount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DataGridviewProduct);
            this.Controls.Add(this.comboSupCate);
            this.Controls.Add(this.textSupProdUnit);
            this.Controls.Add(this.textSupProdPrice);
            this.Controls.Add(this.textSupProdQty);
            this.Controls.Add(this.textSupProdDes);
            this.Controls.Add(this.textSupProd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CustomerStockIn";
            this.Text = "CustomerStockIn";
            this.Load += new System.EventHandler(this.CustomerStockIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridviewProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStockOut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textUnpaidAmount;
        private System.Windows.Forms.TextBox textPaid;
        private System.Windows.Forms.TextBox textTotalAmount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView DataGridviewProduct;
        private System.Windows.Forms.ComboBox comboSupCate;
        private System.Windows.Forms.TextBox textSupProdUnit;
        private System.Windows.Forms.TextBox textSupProdPrice;
        private System.Windows.Forms.TextBox textSupProdQty;
        private System.Windows.Forms.TextBox textSupProdDes;
        private System.Windows.Forms.TextBox textSupProd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView custdataGridView;
        private System.Windows.Forms.TextBox Customer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewStockOut;
        private System.Windows.Forms.TextBox textProdSearch;
        private System.Windows.Forms.TextBox textCustSearch;
        private System.Windows.Forms.TextBox textUpdateSearch;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button Search_Update;
    }
}