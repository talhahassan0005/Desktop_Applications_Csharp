﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class CompanyStockIn : Form
    {
        private string connectionString = "data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"; // Replace with your actual database connection string
        private DataTable productsDataTable;
        private DataTable categoriesDataTable;
        public CompanyStockIn()
        {
            InitializeComponent();
          
            LoadCategories();
        }
       
        private void LoadCategories()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Catid, CatName FROM CustomerCategory";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                categoriesDataTable = new DataTable();
                adapter.Fill(categoriesDataTable);
                comboCategory.DataSource = categoriesDataTable;
                comboCategory.DisplayMember = "CatName";
                comboCategory.ValueMember = "CatId";
            }
        }
        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // Check if the Product Name is empty
            if (string.IsNullOrEmpty(textProductName.Text))
            {
                MessageBox.Show("Product Name cannot be empty.");
                return; // Exit the function
            }

            if (string.IsNullOrEmpty(textDescription.Text))
            {
                MessageBox.Show("Product Name cannot be empty.");
                return; // Exit the function
            }
            // Check if the Qty is a valid integer
            if (!int.TryParse(textQty.Text, out int qty))
            {
                MessageBox.Show("Qty must be a valid integer.");
                return; // Exit the function
            }
            if (!decimal.TryParse(textPrice.Text, out decimal Price))
            {
                MessageBox.Show("Qty must be a valid integer.");
                return; // Exit the function
            }
            if (string.IsNullOrEmpty(comboCategory.Text))
            {
                MessageBox.Show("Product Name cannot be empty.");
                return; // Exit the function
            }
            DateTime date = dateTimePicker1.Value;

            try
            {
                // Create a connection to your database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Create an INSERT query to add the data to the database
                    string insertQuery = "INSERT INTO CompanyStockIn (ProductName, Description, Qty, Price, Category, Date) " +
                                         "VALUES (@ProductName, @Description, @Qty, @Price, @Category, @Date)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", textProductName.Text);
                        cmd.Parameters.AddWithValue("@Description", textDescription.Text);
                        cmd.Parameters.AddWithValue("@Qty", qty); // Use the parsed integer value
                        cmd.Parameters.AddWithValue("@Price", textPrice.Text);
                        cmd.Parameters.AddWithValue("@Category", comboCategory.Text);
                        cmd.Parameters.AddWithValue("@Date", date);

                        cmd.ExecuteNonQuery();
                    }

                    // Optionally, display a success message to the user
                    MessageBox.Show("Data added to the database successfully.");

                    // Clear the input fields for the next entry
                    textProductName.Text = "";
                    textDescription.Text = "";
                    textQty.Text = "";
                    textPrice.Text = "";
                    comboCategory.Text = "";
                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LoadData()
        {
            try
            {
                // Create a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();

                    // SQL query to select all records from your table
                    string query = "SELECT * FROM CompanyStockIn";

                    // Create a SqlDataAdapter to fetch the data
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                    // Create a new DataTable to hold the data
                    System.Data.DataTable dataTable = new System.Data.DataTable();

                    // Fill the DataTable with the data from the database
                    adapter.Fill(dataTable);

                    // Clear existing data in the DataGridView
                    dataGridView1.DataSource = null;
                    dataGridView1.Rows.Clear();
                    dataGridView1.Columns.Clear();

                    // Bind the DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void CompanyStockIn_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    // Get the selected row index
                    int selectedIndex = dataGridView1.SelectedRows[0].Index;

                    // Get the value from the "Productid" column (replace "Productid" with the actual column name)
                    int selectedID = Convert.ToInt32(dataGridView1.Rows[selectedIndex].Cells["Productid"].Value);

                    // Delete the record from the database
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string deleteQuery = "DELETE FROM CompanyStockIn WHERE Productid = @Productid";

                        using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                        {
                            // Use parameterized query to prevent SQL injection
                            cmd.Parameters.AddWithValue("@Productid", selectedID);

                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Remove the selected row from the DataGridView
                    dataGridView1.Rows.RemoveAt(selectedIndex);

                    MessageBox.Show("Record deleted successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    // Get the selected row index
                    int selectedIndex = dataGridView1.SelectedRows[0].Index;

                    // Get the values from the selected row
                    int selectedID = Convert.ToInt32(dataGridView1.Rows[selectedIndex].Cells["Productid"].Value);

                    // Get the values from your form controls
                    string newDescription = textDescription.Text;
                    int newQty = Convert.ToInt32(textQty.Text);
                    string newCategory = comboCategory.Text;
                    DateTime newDate = dateTimePicker1.Value;
                    string newProductName = textProductName.Text;
                    decimal newPrice = Convert.ToDecimal(textPrice.Text);

                    // Update the record in the database
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // Construct the dynamic update query based on the chosen fields
                        string updateQuery = "UPDATE CompanyStockIn SET ";
                        if (!string.IsNullOrEmpty(newDescription))
                        {
                            updateQuery += "Description = @Description, ";
                        }
                        if (newQty != 0)
                        {
                            updateQuery += "Qty = @Qty, ";
                        }
                        if (!string.IsNullOrEmpty(newCategory))
                        {
                            updateQuery += "Category = @Category, ";
                        }
                        if (newDate != DateTime.MinValue)
                        {
                            updateQuery += "Date = @Date, ";
                        }
                        if (!string.IsNullOrEmpty(newProductName))
                        {
                            updateQuery += "ProductName = @ProductName, ";
                        }
                        if (newPrice != 0)
                        {
                            updateQuery += "Price = @Price, ";
                        }

                        // Remove the trailing comma and space
                        updateQuery = updateQuery.TrimEnd(' ', ',');

                        updateQuery += " WHERE Productid = @Productid";

                        using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                        {
                            // Use parameterized query to prevent SQL injection
                            if (!string.IsNullOrEmpty(newDescription))
                            {
                                cmd.Parameters.AddWithValue("@Description", newDescription);
                            }
                            if (newQty != 0)
                            {
                                cmd.Parameters.AddWithValue("@Qty", newQty);
                            }
                            if (!string.IsNullOrEmpty(newCategory))
                            {
                                cmd.Parameters.AddWithValue("@Category", newCategory);
                            }
                            if (newDate != DateTime.MinValue)
                            {
                                cmd.Parameters.AddWithValue("@Date", newDate);
                            }
                            if (!string.IsNullOrEmpty(newProductName))
                            {
                                cmd.Parameters.AddWithValue("@ProductName", newProductName);
                            }
                            if (newPrice != 0)
                            {
                                cmd.Parameters.AddWithValue("@Price", newPrice);
                            }
                            cmd.Parameters.AddWithValue("@Productid", selectedID);

                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Record updated successfully!");

                    // Clear the input fields for the next entry
                    textProductName.Text = "";
                    textDescription.Text = "";
                    textQty.Text = "";
                    textPrice.Text = "";
                    comboCategory.Text = "";
                    // Reload data after update
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }
}
    }

    

