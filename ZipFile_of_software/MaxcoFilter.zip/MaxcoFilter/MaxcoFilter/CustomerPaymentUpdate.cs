﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class CustomerPaymentUpdate : Form
    {
        private string connectionString = "data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework";

        public CustomerPaymentUpdate()
        {
            InitializeComponent();
            PaymentdataGridView.DataSource = FetchDataFromDatabase();
            LoadCustomerStockOutData();
            CustomerLedgerGridView();




        }

            private DataTable FetchDataFromDatabase()
            {
                DataTable table = new DataTable();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                connection.Open();
                string query = "SELECT * FROM CustomerBill";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;
            }

        private void UpdatePaymentRecord(int paymentRecordId, float paidAmount, float unpaidAmount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE PaymentRecords SET PaidAmount = @PaidAmount, UnpaidAmount = @UnpaidAmount WHERE PaymentRecordId = @PaymentRecordId";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@PaidAmount", paidAmount);
                    command.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);
                    command.Parameters.AddWithValue("@PaymentRecordId", paymentRecordId);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to update record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (PaymentdataGridView.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = PaymentdataGridView.SelectedRows[0];
                    int ProductQty = Convert.ToInt32(selectedRow.Cells["ProductQty"].Value);
                    int customerStockOutid = Convert.ToInt32(selectedRow.Cells["CustomerStockOutid"].Value);

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string selectQuery = "SELECT Customerid FROM CustomerBill WHERE CustomerStockOutid = @CustomerStockOutid";

                        using (SqlCommand cmd = new SqlCommand(selectQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@CustomerStockOutid", customerStockOutid);

                            object result = cmd.ExecuteScalar();

                            if (result != null)
                            {
                                Custid = Convert.ToInt32(result);
                                // Now, the "Custid" variable contains the retrieved Customerid.
                            }
                            else
                            {
                                // Handle the case where no result was returned.
                            }
                        }
                    }

                    if (string.IsNullOrWhiteSpace(textUnpaid.Text) || string.IsNullOrWhiteSpace(textPaid.Text))
                    {
                        MessageBox.Show("Please fill in all the fields before updating.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!float.TryParse(textUnpaid.Text, out float payableAmount) || !float.TryParse(textPaid.Text, out float paidAmount))
                    {
                        MessageBox.Show("Please enter valid numeric values for payable and paid amounts.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    InsertRecordCustomerPayment(Custid, ProductQty, customerStockOutid, paidAmount, payableAmount);

                    // Update the corresponding row in the DataGridView
                    selectedRow.Cells["UnpaidAmount"].Value = payableAmount;
                    selectedRow.Cells["PaidAmount"].Value = paidAmount;

                    textUnpaid.Text = "";
                    textPaid.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter valid numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        int Custid;
        private void InsertRecordCustomerPayment(int customerid, int ProductQty, int customerStockOutid, float paidAmount, float unpaidAmount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO CustomerBill (Customerid, CustomerStockOutid, ProductQty, PaidAmount, UnpaidAmount) " +
                                     "VALUES (@Customerid, @CustomerStockOutid, @ProductQty, @PaidAmount, @UnpaidAmount)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Customerid", customerid);
                    cmd.Parameters.AddWithValue("@CustomerStockOutid", customerStockOutid);
                    cmd.Parameters.AddWithValue("@ProductQty", ProductQty);
                    cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                    cmd.Parameters.AddWithValue("@UnpaidAmount", unpaidAmount);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record inserted into CustomerBill successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // You can optionally refresh the DataGridView or take other actions as needed
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert record into CustomerBill.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }


        private void UpdateDatabaseRecordForCustomer(int billId, float payableAmount, float paidAmount)
        {
        using (SqlConnection connection = new SqlConnection("data source=DESKTOP-K64UCEB;initial catalog = MaxcoFilter; integrated security = True; MultipleActiveResultSets=True;App=EntityFramework"))
        {
                try
                {
                    connection.Open();

                    string updateQuery = "UPDATE CustomerBill SET UnpaidAmount = @UnpaidAmount, PaidAmount = @PaidAmount WHERE Billid = @Billid";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@UnpaidAmount", payableAmount);
                        cmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                        cmd.Parameters.AddWithValue("@Billid", billId);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully");
                        }
                        else
                        {
                            MessageBox.Show("Not successful update");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while updating fields: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } 
    }

        private void LoadCustomerStockOutData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string selectQuery = "SELECT * FROM CustomerBill";
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectQuery, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    PaymentdataGridView.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void PaymentdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        private DataTable FetchCustomerDataFromDatabase()
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM CustomerBill";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }
        private DataTable originalDataTable;
        private void CustomerPaymentUpdate_Load(object sender, EventArgs e)
        {

            originalDataTable = FetchDataFromDatabase(); // Make sure to implement this method.

            // Set the DataGridView's data source to originalDataTable.
            PaymentdataGridView.DataSource = originalDataTable;
          
            DataTable customerData = FetchCustomerDataFromDatabase();

            // Set the DataGridView's data source to the retrieved customer data
            PaymentdataGridView.DataSource = customerData;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int customerId = int.Parse(textBox1.Text);

            string query = "SELECT C.CustomerName, CB.Customerid, " +
                           "SUM(CB.PaidAmount) AS TotalPaidAmount, " +
                           "SUM(CB.UnpaidAmount) AS TotalUnpaidAmount, " +
                           "SUM(CB.TotalAmount) AS TotalPayableAmount " +
                           "FROM CustomerBill CB " +
                           "INNER JOIN Customers C ON CB.Customerid = C.Customerid " +
                           "WHERE CB.Customerid = @CustomerId " +
                           "GROUP BY C.CustomerName, CB.Customerid";



            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CustomerId", customerId);

                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                string customerName = reader["CustomerName"].ToString();
                                float totalPaidAmount = float.Parse(reader["TotalPaidAmount"].ToString());
                                float totalUnpaidAmount = float.Parse(reader["TotalUnpaidAmount"].ToString());
                                float totalPayableAmount = float.Parse(reader["TotalPayableAmount"].ToString());

                                // Display the fetched data in dataGridViewCustPayament
                                dataGridViewCustPayament.Rows.Clear();
                                dataGridViewCustPayament.Rows.Add(customerName, totalPaidAmount, totalUnpaidAmount, totalPayableAmount);
                            }
                        }
                        else
                        {
                            MessageBox.Show("No data found for the provided Customer ID.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                DataView dataView = originalDataTable.DefaultView;
                dataView.RowFilter = $"Customerid LIKE '%{textBox1.Text}%'"; // Modify the filter condition to search by Customerid.
                PaymentdataGridView.DataSource = dataView.ToTable();
            }
            else
            {
                PaymentdataGridView.DataSource = originalDataTable; // Show all records when the filter text is empty.
            }

        }
        private void LoadSupplierLegerData()
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PaymentdataGridView.DataSource = FetchDataFromDatabase();
            LoadCustomerStockOutData();
            CustomerLedgerGridView();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textPaid.Text) && decimal.TryParse(textPaid.Text, out decimal paidAmount))
                {
                    if (PaymentdataGridView.SelectedRows.Count > 0)
                    {
                        DataGridViewRow selectedRow = PaymentdataGridView.SelectedRows[0];

                        if (selectedRow.Cells["Billid"].Value != null &&
                            selectedRow.Cells["Customerid"].Value != null &&
                            selectedRow.Cells["UnpaidAmount"].Value != null)
                        {
                            int billId = Convert.ToInt32(selectedRow.Cells["Billid"].Value);
                            string customerId = selectedRow.Cells["Customerid"].Value.ToString();
                            decimal totalAmount = Convert.ToDecimal(selectedRow.Cells["TotalAmount"].Value);
                            decimal unpaidAmount = Convert.ToDecimal(selectedRow.Cells["UnpaidAmount"].Value);
                            decimal remainingAmount = unpaidAmount - paidAmount;

                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                SqlTransaction transaction = connection.BeginTransaction();

                                try
                                {
                                    string updateQuery = "UPDATE CustomerBill SET UnpaidAmount = @RemainingAmount, PaidAmount = PaidAmount + @PaidAmount WHERE Billid = @Billid";

                                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, connection, transaction))
                                    {
                                        updateCmd.Parameters.AddWithValue("@RemainingAmount", remainingAmount);
                                        updateCmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                                        updateCmd.Parameters.AddWithValue("@Billid", billId);

                                        int rowsAffected = updateCmd.ExecuteNonQuery();

                                        if (rowsAffected > 0)
                                        {
                                            string insertLedgerQuery = "INSERT INTO CustomerLedger (Customerid, PaidAmount, UnpaidAmount, TotalAmount, Date) " +
                                                                       "VALUES (@CustomerId, @PaidAmount, @UnpaidAmount, @TotalAmount, @TransactionDate)";

                                            using (SqlCommand ledgerCmd = new SqlCommand(insertLedgerQuery, connection, transaction))
                                            {
                                                ledgerCmd.Parameters.AddWithValue("@CustomerId", customerId);
                                                ledgerCmd.Parameters.AddWithValue("@PaidAmount", paidAmount);
                                                ledgerCmd.Parameters.AddWithValue("@UnpaidAmount", remainingAmount);
                                                ledgerCmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                                                ledgerCmd.Parameters.AddWithValue("@TransactionDate", dateTimePicker1.Value.Date);

                                                int ledgerRowsAffected = ledgerCmd.ExecuteNonQuery();

                                                if (ledgerRowsAffected > 0)
                                                {
                                                    transaction.Commit();
                                                    MessageBox.Show("Payment recorded successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                }
                                                else
                                                {
                                                    transaction.Rollback();
                                                    MessageBox.Show("Failed to record payment in the ledger.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            transaction.Rollback();
                                            MessageBox.Show("Failed to update the unpaid amount in the 'CustomerBill' table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Selected row does not contain necessary data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record from the DataGridView.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric payment amount.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void CustomerLedgerGridView()
        {
            try
            {
                // Your payment transaction code...

                // Refresh CustomerLedgerGridView after successful transaction
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM CustomerLedger", connectionString);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewCustPayament.DataSource = dataTable;
                dataGridViewCustPayament.Refresh(); // Refresh the DataGridView to reflect updated data
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewCustPayament_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          CustomerLedgerGridView();
        }


        private void textUnpaid_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void PaymentdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0) // Ensure a valid cell within a row is clicked
            {
                DataGridViewRow selectedRow = PaymentdataGridView.Rows[e.RowIndex];
                int unpaidColumnIndex = PaymentdataGridView.Columns["UnpaidAmount"].Index;

                if (e.ColumnIndex == unpaidColumnIndex)
                {
                    // Autofill textUnpaid with UnpaidAmount value from the clicked row
                    if (selectedRow.Cells[unpaidColumnIndex].Value != null && selectedRow.Cells[unpaidColumnIndex].Value != DBNull.Value)
                    {
                        textUnpaid.Text = selectedRow.Cells[unpaidColumnIndex].Value.ToString();
                    }
                }
            }
        }

        private void textPaid_TextChanged(object sender, EventArgs e)
        {

            try
            {
                if (decimal.TryParse(textPaid.Text, out decimal paidAmount))
                {
                    if (PaymentdataGridView.SelectedRows.Count > 0)
                    {
                        DataGridViewRow selectedRow = PaymentdataGridView.SelectedRows[0];

                        if (selectedRow.Cells["UnpaidAmount"].Value != null && selectedRow.Cells["CustomerStockOutId"].Value != null)
                        {
                            decimal payableAmount = Convert.ToDecimal(selectedRow.Cells["UnpaidAmount"].Value);
                            decimal unpaidAmount = payableAmount - paidAmount;

                            // Update the text box with the new unpaid amount
                            textUnpaid.Text = unpaidAmount.ToString();
                        }
                    }
                }
                else
                {
                    // Clear the text box if the entered paid amount is not a valid decimal
                    textUnpaid.Text = "";
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that might occur
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewCustPayament.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridViewCustPayament.SelectedRows[0];

                    // Get the TransactionID from the first cell (assuming it's at index 0)
                    if (selectedRow.Cells[0].Value != null &&
                        int.TryParse(selectedRow.Cells[0].Value.ToString(), out int transactionID))
                    {
                        // Construct the SQL delete query
                        string deleteQuery = "DELETE FROM CustomerLedger WHERE LegerID = @LegerID";

                        // Execute the deletion
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@LegerID", transactionID);
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LoadSupplierLegerData(); // Refresh data after deletion
                                }
                                else
                                {
                                    MessageBox.Show("Record deletion failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Unable to retrieve LegerID from the selected row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
