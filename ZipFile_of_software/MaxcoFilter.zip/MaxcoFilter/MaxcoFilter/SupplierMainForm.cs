﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace MaxcoFilter
{
    public partial class SupplierMainForm : Form
    {
        private Form1 childForm;
        public SupplierMainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form existingForm = panel1.Controls.OfType<Form>().FirstOrDefault();
            if (existingForm != null)
            {
                existingForm.Close();
            }
            Form1 existingForm1 = new Form1(); // Create an instance of your existing Form1
            existingForm1.TopLevel = false;
            existingForm1.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(existingForm1); // Add the existing Form1 to panel1
            existingForm1.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            existingForm1.Show();
        }

        private void SupplierMainForm_Load(object sender, EventArgs e)
        {

        }
      
        private void button4_Click(object sender, EventArgs e)
        {
            // Close all existing forms in panel1
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            SupplierRep supplierStockoutForm = new SupplierRep();
            supplierStockoutForm.TopLevel = false;
            supplierStockoutForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockoutForm); // Add the new form to panel1
            supplierStockoutForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockoutForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form existingForm = panel1.Controls.OfType<Form>().FirstOrDefault();
            if (existingForm != null)
            {
                existingForm.Close();
            }

            // Create and show the new form
            SupplierProduct newForm = new SupplierProduct();
            newForm.TopLevel = false;
            newForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(newForm); // Add the new form to panel1
            newForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            newForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Close all existing forms in panel1
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            StockIn supplierStockInForm = new StockIn();
            supplierStockInForm.TopLevel = false;
            supplierStockInForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockInForm); // Add the new form to panel1
            supplierStockInForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockInForm.Show();

        }

        private void button7_Click(object sender, EventArgs e)
        { // Close all existing forms in panel1
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            SupplierPayment supplierStockInForm = new SupplierPayment();
            supplierStockInForm.TopLevel = false;
            supplierStockInForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockInForm); // Add the new form to panel1
            supplierStockInForm.Dock = DockStyle.Fill; // Optional: Dock the form to fill the panel
            supplierStockInForm.Show();


        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Form form)
                {
                    form.Close();
                }
            }

            // Create and show the SupplierStockIn form
            SupplierStockOut supplierStockInForm = new SupplierStockOut();
            supplierStockInForm.TopLevel = false;
            supplierStockInForm.FormBorderStyle = FormBorderStyle.None; // Optional: Remove the border of the form
            panel1.Controls.Add(supplierStockInForm); // Add the new form to panel1
            supplierStockInForm.Dock = DockStyle.Fill;
            // Optional: Dock the form to fill the panel
            supplierStockInForm.Show();
           
        }
        
        private void button8_Click(object sender, EventArgs e)
        {
            MaxcoStockIn form = new MaxcoStockIn(); // Replace with your form's name
            form.TopLevel = false; // Set TopLevel property to false to use it within another container
            form.FormBorderStyle = FormBorderStyle.None; // Optional: Remove border if needed
            form.Dock = DockStyle.Fill; // Optional: Dock it within the panel

            // Add the form to the panel's controls
            panel1.Controls.Clear(); // Clear previous controls
            panel1.Controls.Add(form);

            // Show the form
            form.Show();
        }
    }
}
