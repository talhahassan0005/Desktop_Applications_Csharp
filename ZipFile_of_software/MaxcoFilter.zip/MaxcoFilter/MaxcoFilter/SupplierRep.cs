﻿using CrystalDecisions.CrystalReports.Engine;
using MaxcoFilter.Models.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxcoFilter
{
    public partial class SupplierRep : Form
    {
        public SupplierRep()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        

                        try
                          {
                        ReportDocument reportDocument = new ReportDocument();

                        // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                        reportDocument.Load(@"E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\Models\Reports\SupplierReport.rpt");

                        // Set the ReportDocument as the source for the CrystalReportViewer
                        crystalReportViewer1.ReportSource = reportDocument;

                        // Refresh the CrystalReportViewer
                        crystalReportViewer1.Refresh();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading report: " + ex.Message);
                    }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@"E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\Models\Reports\RawMaterialUsed.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@"E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\Models\Reports\SupplierLeger.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
                   
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@"E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\Models\Reports\Purchased_Products.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
    
}
