﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;


namespace MaxcoFilter
{
    public partial class CustomerReport : Form
    {
        public CustomerReport()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@"E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\CustomerReports\Customers.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }
        }
       
        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@" E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\CustomerReports\CustomerStockOut.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
           
                 try
            {
                ReportDocument reportDocument = new ReportDocument();

                // Load your SupplierReport Crystal Report file (.rpt) into the ReportDocument
                reportDocument.Load(@"  E:\Jan ka Azaab\MaxcoFilter\MaxcoFilter\CustomerReports\CompanyStockProduct.rpt");

                // Set the ReportDocument as the source for the CrystalReportViewer
                crystalReportViewer1.ReportSource = reportDocument;

                // Refresh the CrystalReportViewer
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading report: " + ex.Message);
            }
        }
    }
}
